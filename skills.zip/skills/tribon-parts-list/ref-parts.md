# Tribon M3 零件清单 COM 接口参考

## TbPartsListGen.TbAssPartsListGen（11个成员）

```powershell
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
```

### 方法

| 方法 | 参数 | 说明 |
|------|------|------|
| `GeneratePartsList(assemblyName)` | 装配名 | 生成零件清单 |
| `GetAssemblyProperties(assemblyName)` | 装配名 | 获取装配属性对象 |
| `GetLastError()` | — | 获取最后错误码 |
| `GetLastErrorMsg()` | — | 获取最后错误消息 |

### 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `CalculateProperties` | bool | 是否计算属性（重量/COG） |
| `CumulateBracketParts` | bool | 是否累积支架零件 |
| `CumulateHullParts` | bool | 是否累积船体零件 |
| `ExtendedComponentDescr` | bool | 扩展组件描述 |
| `OutputDirectory` | string | 输出目录路径 |
| `OutputFileNameType` | int | 输出文件名类型 |
| `Recursive` | bool | 是否递归子装配 |

---

## TbPartsListGen.TbAssemblyProperties（35个成员）

`GetAssemblyProperties()` 返回此对象。

### 方法

| 方法 | 说明 |
|------|------|
| `GetPartCount()` | 返回直接子零件数量（整数） |
| `GetPartProperties(index)` | 返回第 index 个零件的 TbPartProperties 对象（0-based） |
| `GetSubAssembliesCount()` | 返回直接子装配数量（整数） |
| `GetSubAssembly(index)` | 返回第 index 个子装配的 TbAssemblyProperties 对象（0-based） |

### 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `NodeName` | string | 节点名称（装配名） |
| `PathName` | string | 完整路径名 |
| `InternalName` | string | 内部名称 |
| `ProjectName` | string | 项目名称 |
| `Description` | string | 描述 |
| `AssemblyType` | string | 装配类型 |
| `AssemblyStatus` | string | 装配状态 |
| `DesignStatus` | string | 设计状态 |
| `ManufacturingStatus` | string | 制造状态 |
| `MaterialStatus` | string | 材料状态 |
| `LevelId` | int | 层级 ID |
| `ParentLevelId` | int | 父层级 ID |
| `ShortLevelDesc` | string | 层级短描述 |
| `LongLevelDesc` | string | 层级长描述 |
| `ParentShortLevelDesc` | string | 父层级短描述 |
| `ParentLongLevelDesc` | string | 父层级长描述 |
| `PlanningUnit` | string | 计划单元 |
| `WorkLocation` | string | 工作位置 |
| `Destination` | string | 目标 |
| `Orientation` | string | 装配方向 |
| `SpecificPanel` | string | 特定面板 |
| `PanelType` | string | 面板类型 |
| `CostCode` | string | 成本代码 |
| `Remarks` | string | 备注 |
| `EstimatedWeight` | double | 估算重量（kg） |
| `CalculatedWeight` | double | 计算重量（kg） |
| `GlobalCOGCalcDate` | string | 全局重心计算日期 |
| `PlannedStartDate` | string | 计划开始日期 |
| `PlannedEndDate` | string | 计划结束日期 |
| `ActualStartDate` | string | 实际开始日期 |
| `ActualEndDate` | string | 实际结束日期 |

---

## TbPartsListGen.TbPartProperties（18个成员）

`GetPartProperties(index)` 返回此对象。

| 属性 | 类型 | 说明 |
|------|------|------|
| `ID` | string | 零件 ID |
| `Name` | string | 零件名称 |
| `CustomPartName` | string | 自定义零件名 |
| `NestingName` | string | 套料名称 |
| `Type` | string | 类型（如 plate、profile） |
| `PartType` | string | 零件类型 |
| `Description` | string | 描述 |
| `AssemblyName` | string | 所属装配名 |
| `ComponentName` | string | 组件名 |
| `MaterialNumber` | string | 材料编号 |
| `Quality` | string | 质量等级 |
| `Weight` | double | 重量（kg） |
| `Quantity` | int | 数量 |
| `PositionNumber` | string | 位置号 |
| `ManufacturingCode` | string | 制造代码 |
| `CostCode` | string | 成本代码 |
| `Purpose` | string | 用途 |
| `Comment` | string | 注释 |

---

## TBModelCalculations.TBModelCalc

```powershell
$mc = New-Object -ComObject 'TBModelCalculations.TBModelCalc'
$result = $mc.GetWeightAndCOG("BLOCK-001", "assembly")
```

| 方法 | 说明 |
|------|------|
| `GetWeightAndCOG(name, type)` | 计算重量和重心，type 可为 "assembly"、"panel" 等 |
| `SetDefaultModelType(type)` | 设置默认模型类型 |

返回对象属性：`Weight`、`COGX`、`COGY`、`COGZ`
