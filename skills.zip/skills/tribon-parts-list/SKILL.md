---
name: tribon-parts-list
description: Tribon M3 零件清单（已整合到 tribon-tasks，请使用 tribon-tasks 技能）
version: "1.0"
platform:
  - windows
triggers: []
---

> 此技能已整合到 **tribon-tasks** 技能中。请使用 tribon-tasks 获取完整的 Tribon M3 操作支持。