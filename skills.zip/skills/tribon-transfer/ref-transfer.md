# Tribon M3 数据传输参考

## Tbtransfer.TBTransferSet（19个成员）

```powershell
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
```

### 方法详解

| 方法 | 返回类型 | 说明 |
|------|---------|------|
| `OpenProject(projectName)` | void | 打开指定项目，设置传输上下文 |
| `DumpCollection()` | void | 执行传输（导出集合到目标） |
| `GetArchive()` | object | 获取归档对象 |
| `GetCheckpointInfo()` | string | 获取所有检查点信息（JSON/XML格式） |
| `GetLastCheckpointInfo()` | string | 获取最后一个检查点信息 |
| `GetDrawingTypeMapping()` | object | 获取图纸类型映射表 |
| `GetDrawingTypes()` | object | 获取可用图纸类型列表 |
| `GetOptions()` | object | 获取传输选项对象 |
| `GetSelection()` | object | 获取传输选择对象（要传输的对象集合） |
| `GetSisterShip()` | object | 获取姊妹船配置对象 |
| `ResumeCheckpoint(checkpointId)` | void | 从指定检查点恢复传输 |
| `ResumeLastCheckpoint()` | void | 从最后检查点恢复传输（断点续传） |

### 属性详解

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `Label` | string | "" | 传输批次标签（用于识别） |
| `Comment` | string | "" | 传输注释说明 |
| `ShowConsole` | bool | false | 是否显示传输进度控制台 |
| `EnableCheckpoints` | bool | false | 是否启用检查点（支持断点续传） |
| `CheckpointInterval` | int | 0 | 每传输 N 个对象保存一次检查点 |
| `AutoDeleteCheckpoints` | bool | true | 传输完成后自动删除检查点文件 |
| `SisterShipMode` | bool | false | 是否为姊妹船复制模式 |

---

## Tbexpimp 接口

### Tbexpimp.TBEffectivity（8个成员）

```powershell
$eff = New-Object -ComObject 'Tbexpimp.TBEffectivity'
```

用于管理对象的有效性（effectivity），控制哪些版本/配置的对象参与传输。

### Tbexpimp.TBSelectionList（3个成员）

```powershell
$sel = New-Object -ComObject 'Tbexpimp.TBSelectionList'
```

用于定义传输选择列表（要导入/导出的对象集合）。

---

## 文档服务接口

### TbDocumentSrv.TBDocuments（3个成员）

```powershell
$docs = New-Object -ComObject 'TbDocumentSrv.TBDocuments'
```

### TbDocumentSrv.TBVault（2个成员）

```powershell
$vault = New-Object -ComObject 'TbDocumentSrv.TBVault'
```

### TbDocumentSrv.TBReference（2个成员）

```powershell
$ref = New-Object -ComObject 'TbDocumentSrv.TBReference'
```

### TbDocumentSrv.TBDocument（完整接口）

```powershell
$doc = New-Object -ComObject 'TbDocumentSrv.TBDocument'
```

| 方法 | 说明 |
|------|------|
| `LoadFromFile(path)` | 从文件加载文档 |
| `Save()` | 保存文档 |
| `SaveToFile(path)` | 保存到文件 |

| 属性 | 说明 |
|------|------|
| `Class` | 文档类 |
| `Description` | 描述 |
| `DocId` | 文档 ID |
| `FileExtension` | 文件扩展名 |
| `FileName` | 文件名 |
| `MimeType` | MIME 类型 |
| `Name` | 名称 |
| `OriginalPath` | 原始路径 |
| `RefName` | 引用名 |
| `Size` | 文件大小 |

---

## 典型传输场景

### 场景一：标准项目间传输

```powershell
# com_invoke, arch=x86
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("SOURCE_PROJECT")
$ts.Label = "Transfer-" + (Get-Date -Format "yyyyMMdd")
$ts.Comment = "定期数据同步"
$ts.ShowConsole = $true
$ts.EnableCheckpoints = $true
$ts.CheckpointInterval = 500
$ts.DumpCollection()
```

### 场景二：姊妹船复制

```powershell
# com_invoke, arch=x86
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("SHIP_001")
$ts.SisterShipMode = $true
$ts.Label = "SisterShip-SHIP_002"
$sisterConfig = $ts.GetSisterShip()
# 配置姊妹船映射...
$ts.DumpCollection()
```

### 场景三：断点续传

```powershell
# com_invoke, arch=x86
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("SOURCE_PROJECT")
$lastCp = $ts.GetLastCheckpointInfo()
if ($lastCp -ne $null -and $lastCp -ne "") {
    Write-Output ("发现未完成的传输，从检查点恢复: " + $lastCp)
    $ts.ResumeLastCheckpoint()
} else {
    Write-Output "开始新的传输"
    $ts.EnableCheckpoints = $true
    $ts.DumpCollection()
}
```
