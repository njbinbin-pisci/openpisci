# Tribon M3 打印服务参考

## TBPrintSrv COM 接口总览

| ProgID | 成员数 | 说明 |
|--------|--------|------|
| `TBPrintSrv.TBApplication` | — | 打印应用（需 Initialize/Terminate） |
| `TBPrintSrv.PrintJob` | 4 | 打印作业 |
| `TBPrintSrv.Printer` | 8 | 打印机配置 |
| `TBPrintSrv.FindDrawings` | 2 | 图纸查找 |
| `TBPrintSrv.Drawing` | 7 | 单张图纸 |
| `TBPrintSrv.Drawings` | 0 | 图纸集合 |

---

## TBPrintSrv.TBApplication

```powershell
$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()
# ... 执行打印操作 ...
$app.Terminate()
```

打印应用的生命周期管理，所有打印操作应在 Initialize/Terminate 之间执行。

---

## TBPrintSrv.PrintJob

```powershell
$pj = New-Object -ComObject 'TBPrintSrv.PrintJob'
```

| 成员 | 类型 | 说明 |
|------|------|------|
| `StartPrint()` | 方法 | 执行打印，同步等待完成 |
| `Drawings` | 属性（读写） | 要打印的图纸集合（TBPrintSrv.Drawings） |
| `Printer` | 属性（读写） | 打印机配置（TBPrintSrv.Printer） |
| `PrintOptions` | 属性（读写） | 打印选项对象 |

---

## TBPrintSrv.Printer

```powershell
$printer = New-Object -ComObject 'TBPrintSrv.Printer'
```

| 成员 | 类型 | 说明 |
|------|------|------|
| `SelectPrinter()` | 方法 | 弹出系统打印机选择对话框 |
| `ShowPageSetupDlg()` | 方法 | 弹出页面设置对话框 |
| `ShowPrintSetupDlg()` | 方法 | 弹出打印设置对话框 |
| `DeviceName` | string | 打印机设备名称（如 "Microsoft Print to PDF"） |
| `Orientation` | int | 方向：1=纵向（Portrait），2=横向（Landscape） |
| `PaperSize` | int | 纸张大小代码（A4=9，A3=8，A1=25，A0=46） |
| `PaperWidth` | int | 纸张宽度（单位：0.1mm，如 2100=210mm） |
| `PaperLength` | int | 纸张长度（单位：0.1mm，如 2970=297mm） |

### 常用纸张大小代码

| 代码 | 纸张 | 尺寸 |
|------|------|------|
| 8 | A3 | 297×420mm |
| 9 | A4 | 210×297mm |
| 25 | A1 | 594×841mm |
| 46 | A0 | 841×1189mm |

---

## TBPrintSrv.FindDrawings

```powershell
$fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
```

| 属性 | 类型 | 说明 |
|------|------|------|
| `DrawingType` | string | 图纸类型（见下表） |
| `Filter` | string | 图纸名称过滤（支持 `*` 通配符） |

### 图纸类型（DrawingType）

| 值 | 说明 |
|----|------|
| `"HULL"` | 船体图纸 |
| `"PIPE"` | 管路图纸 |
| `"EQUIP"` | 设备图纸 |
| `"CABLE"` | 电缆图纸 |
| `"STRUCT"` | 结构图纸 |
| `"OUTFITTING"` | 舾装图纸 |

---

## TBPrintSrv.Drawing（7个成员）

单张图纸对象，通过 `FindDrawings.Find()` 或 `Drawings` 集合获取。

常见属性：`Name`（图纸名）、`Type`（类型）、`Status`（状态）、`Revision`（版本）、`Description`（描述）

---

## 完整批量打印脚本

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Continue'

param(
    [string]$DrawingType = "HULL",
    [string]$Filter = "*",
    [string]$PrinterName = "Microsoft Print to PDF",
    [int]$Orientation = 2,   # 2=横向
    [int]$PaperSize = 8      # 8=A3
)

$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()

try {
    # 查找图纸
    $fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
    $fd.DrawingType = $DrawingType
    $fd.Filter = $Filter
    $drawings = $fd.Find()
    
    if ($drawings -eq $null -or $drawings.Count -eq 0) {
        Write-Output "未找到匹配的图纸"
    } else {
        Write-Output ("找到 " + $drawings.Count + " 张图纸，开始打印...")
        
        # 配置打印作业
        $pj = New-Object -ComObject 'TBPrintSrv.PrintJob'
        $pj.Printer.DeviceName = $PrinterName
        $pj.Printer.Orientation = $Orientation
        $pj.Printer.PaperSize = $PaperSize
        $pj.Drawings = $drawings
        
        # 执行打印
        $pj.StartPrint()
        Write-Output ("打印完成: " + $drawings.Count + " 张")
    }
} catch {
    Write-Output ("打印错误: " + $_.Exception.Message)
} finally {
    $app.Terminate()
}
```
