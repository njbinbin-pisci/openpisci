# Tribon M3 宏语言（GML）参考

GML（Graphical Macro Language）是 Tribon M3 的内置宏语言，用于自动化操作和批量处理。

---

## 基本结构

```
MACRO,宏名称;
   [宏体]
ENDMACRO;
```

---

## 变量声明与赋值

```
ASSIGN,变量名,值;
ASSIGN,变量名,表达式;

# 字符串连接（!! 运算符）
ASSIGN,STR, 'PIPE(''300'').PIPSPOOL(''M4-SA1-A'').' !! 'GEN_PROP.WEIGHT';

# 算术运算
ASSIGN,K,J+1;
ASSIGN,K,K+1;
```

---

## 数据类型

| 类型 | 声明方式 | 说明 |
|------|---------|------|
| 字符串 | `ASSIGN,VAR,'值'` | 用单引号括起 |
| 整数 | `ASSIGN,VAR,42` | 直接赋值 |
| 实数 | `ASSIGN,VAR,3.14` | 小数点 |
| 2D 点 | `POINT_2D,P1,X,Y` | 二维坐标 |
| 3D 点 | `POINT_3D,P1,X,Y,Z` | 三维坐标 |
| 向量 | `VECTOR_3D,V1,X,Y,Z` | 三维向量 |
| 2D 向量 | `VECTOR_2D,V1,X,Y` | 二维向量 |

---

## 数据抽取

```
# 定义抽取表达式
EXTRACTION,变量名,表达式字符串;

# 获取范围（顶层对象列表）
GET/RANGE=(结果变量,抽取变量);
GET/RANGE=(结果变量,STAT,TREE,);
GET/RANGE=(结果变量,STAT,TREE,,父级1,父级2);

# 获取具体值
GET/EXTRACT=(值变量,抽取变量,范围变量,键名,,);
GET/EXTRACT=(WEIGHT,J,PROJ,PIPNAME,,);

# 获取结构（数组）
GET/STRUCTURE=(N,变量,-1);        # 获取数组长度
GET/STRUCTURE=(元素变量,数组变量,索引);  # 获取第N个元素
```

---

## 控制流

### 条件判断

```
IF,条件;
   [真分支]
ELSE;
   [假分支]
ENDIF;

# 示例
IF,STAT == 1;
   PUT,WEIGHT;
ENDIF;

IF,K <= N;
   GET/STRUCTURE=(P2,PARAM,K);
ENDIF;
```

### 循环

```
LOOP,循环变量,范围;
   [循环体]
ENDLOOP;

# 示例：遍历范围
LOOP,PROJ,PROJECT;
   GET/EXTRACT=(WEIGHT,J,PROJ,PIPNAME,,);
ENDLOOP;

# 示例：数字范围
LOOP,J,1:N::3;    # 从1到N，步长3
   ...
ENDLOOP;
```

---

## 输出操作

### 表格输出

```
TABLE,TAB/ARGUMENTS=(参数1,参数2,...)/FILENAME=文件名/FORMAT=(格式)/NOAPPEND;

# 格式说明
# -60,    左对齐，宽度60
# 5,0     整数，宽度5
# 10,2    实数，宽度10，2位小数
# -24,,   字符串，宽度24

# 示例
TABLE,TAB/ARGUMENTS=(HEAD)/FILENAME=FILENAME/FORMAT=(-60,)/NOAPPEND;
TABLE,TAB/ARGUMENTS=(PANEL,STI,I,P1,P2,P3)/FILENAME=FILENAME/FORMAT=(-24,,5,0,5,0,10,2,10,2,10,2);
```

### 显示对象

```
PRESENT,对象名;
```

### 打印变量

```
PUT,变量名;
```

---

## 几何操作

### 点定义

```
POINT_2D,P1,X,Y;
POINT_3D,P1,X,Y,Z;
```

### 向量定义

```
VECTOR_3D,V1,1,0,0;    # X 方向单位向量
VECTOR_2D,V1,X,Y;
```

### 轮廓

```
CONTOUR,CNT,P1/LINEEND=P2;      # 直线段
CONTOUR,CNT,P1/ARCEND=P2,R;     # 圆弧段
```

### 直线

```
LINE,L1,P4/LINEEND=P5;
```

### 文字

```
TEXT,TXT,TXP/TEXTLINE='文字内容';
TEXTFILE,TXF,'数据文件'/POSLINES=(TXP,1,N);  # 从文件读取文本
```

---

## 几何体（3D 建模）

### 圆柱体

```
CYLINDER,CYL1,半径/COORDCYL=(起点,终点);
```

### 圆锥体

```
CONE,CON1,起始半径,终止半径/COORDCONE=(P,顶点);
```

### 球面段

```
SPHERESEG,SPH1,半径/COORDSEG=(起点,终点);
```

### 环形体（弯管）

```
TOROID,TOR1,半径/COORDTOR=(起点,中点,终点);
```

### 通用柱体

```
GENERALCYLINDER,GCL1,轮廓,长度,P1,P2,P3;
```

### 平行六面体

```
PARALLELEPIPED,PAR1/CENLINPARA=(P1,P2,P3);
```

---

## 交互输入

```
GET/POINT_2D=('提示文字',变量名);
GET/POINT_3D=('提示文字',变量名);
GET/DECIMAL=('提示文字',变量名);
GET/DISTANCE=('提示文字',变量名);
```

---

## 颜色设置

```
COLOUR,'RED';
COLOUR,'BLUE';
COLOUR,'GREEN';
COLOUR,'WHITE';
COLOUR,'YELLOW';
```

---

## 数学函数

```
COSD(角度)    # 余弦（度）
SIND(角度)    # 正弦（度）
```

---

## 完整示例：加强筋端部参数提取

```
MACRO, STIF; 
ASSIGN,FILENAME,'STIF.LST'; 
ASSIGN,TB,'TB172-';
ASSIGN,STR,'HUL.PAN(TB*).STI(1:27).END(1:2).CUT.PAR';
EXTRACT,TREE,STR;
ASSIGN,HEAD,' OBJECT                    STI  END    PARAMETERS';
TABLE,TAB/ARGUMENTS=(HEAD)/FILENAME=FILENAME/FORMAT=(-60,)/NOAPPEND;

GET/RANGE=(PANELS,STAT,TREE,);
IF,STAT == 1;
  LOOP,PANEL,PANELS;
    GET/RANGE=(STIFFENERS,STAT,TREE,,PANEL);
    IF,STAT == 1;
      LOOP,STI,STIFFENERS;
        GET/RANGE=(RNG,STAT,TREE,,PANEL,STI);
        IF,STAT == 1;
           LOOP,I,RNG;
             GET/EXTRACT=(PARAM,STAT,TREE,,PANEL,STI,I,,);
             IF,STAT == 1;
                GET/STRUCTURE=(N,PARAM,-1);
                LOOP,J,1:N::3;
                   ASSIGN,K,J;
                   GET/STRUCTURE=(P1,PARAM,K);
                   ASSIGN,K,K+1;
                   IF,K <= N;
                      GET/STRUCTURE=(P2,PARAM,K);
                      ASSIGN,K,K+1;
                      IF,K <= N;
                         GET/STRUCTURE=(P3,PARAM,K);
                         TABLE,TAB/ARGUMENTS=(PANEL,STI,I,P1,P2,P3)
                                  /FILENAME=FILENAME
                                  /FORMAT=(-24,,5,0,5,0,10,2,10,2,10,2);
                      ENDIF;
                   ENDIF;
                 ENDLOOP;
               ENDIF;
            ENDLOOP;
         ENDIF;
       ENDLOOP;
     ENDIF;
   ENDLOOP;
 ENDIF;
ENDMACRO;
```

---

## 完整示例：管路重量抽取

```
MACRO,DEXJ;
   ASSIGN,PIPNAME,'M4-SA1-A';
   ASSIGN,STR,
      'PIPE(''300'').PIPSPOOL(''M4-SA1-A'').' !!
      'GEN_PROP.WEIGHT';
   EXTRACTION,J,STR;
   GET/RANGE=(PROJECT,J);
   PUT,PROJECT;
   LOOP,PROJ,PROJECT;
      GET/EXTRACT=(WEIGHT,J,PROJ,PIPNAME,,);
      PUT,WEIGHT;
   ENDLOOP;
ENDMACRO;
```

---

## 官方文档参考

- `C:\Tribon\M3\Documentation\basic_macro_dex.txt` — 数据抽取宏
- `C:\Tribon\M3\Documentation\basic_macro_dexj.txt` — 管路数据抽取宏
- `C:\Tribon\M3\Documentation\basic_macro_stif.txt` — 加强筋参数宏
- `C:\Tribon\M3\Documentation\macro_list.txt` — 图纸列表宏
- `C:\Tribon\M3\Documentation\macro_pump.txt` — 泵 3D 建模宏
- `C:\Tribon\M3\Documentation\Cutout_Macro_example.txt` — 剪口轮廓宏（337行完整示例）
