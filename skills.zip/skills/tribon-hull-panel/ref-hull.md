# Tribon M3 船体面板参考

## kcs_hullpan 模块完整接口

| 函数 | 参数 | 说明 |
|------|------|------|
| `pan_activate(name)` | 面板名 | 激活面板进入编辑模式 |
| `pan_store(name?)` | 面板名（可选） | 保存面板修改，无参数则保存所有 |
| `pan_skip(name?)` | 面板名（可选） | 放弃面板修改 |
| `pan_delete(name)` | 面板名 | 删除面板 |
| `pan_list_active()` | — | 返回已激活面板名列表 |
| `pan_copy(src, dst, opts)` | 源名、目标名、选项 | 复制面板 |
| `pan_move(name, opts)` | 面板名、选项 | 移动面板 |
| `pan_recreate(name)` | 面板名 | 重建面板 |
| `pan_split(name, plane, new_name, block, sym)` | 面板名、平面、新名、分段、对称码 | 分割面板 |
| `pan_topology(name, type)` | 面板名、拓扑类型 | 查询拓扑关系 |
| `pan_remove_seam(name, seam_id)` | 面板名、接缝ID | 删除接缝 |
| `pan_group_delete(name, dict)` | 面板名、组字典 | 删除组 |
| `pan_group_divide(name, dict, models)` | 面板名、组字典、模型列表 | 分割组 |
| `pan_sti_split_by_model(part_id, opts)` | 加强筋部件ID、选项 | 按模型分割加强筋 |
| `pan_sti_split_by_plane(part_id, opts)` | 加强筋部件ID、选项 | 按平面分割加强筋 |

## 拓扑类型

| 类型字符串 | 说明 |
|-----------|------|
| `"defining"` | 定义面板（该面板依赖的面板） |
| `"dependent primary"` | 主要依赖面板（依赖该面板的面板） |
| `"dependent all"` | 所有依赖面板 |

## KcsModel 类（来自 KcsModel.py）

```python
from KcsModel import Model

m = Model()
m.Type = "plane panel"    # 模型类型
m.Name = "JUMBO-BHD122"   # 名称
m.PartType = "plate"      # 部件类型
m.PartId = 1              # 部件 ID（整数）
m.SubPartType = ""        # 子部件类型
m.SubPartId = 0           # 子部件 ID
m.ReflCode = 0            # 反射代码（0=未反射，1=已反射，2=两者）
```

### 模型类型（Type）

```
"plane panel"       # 平面面板
"hull curve"        # 船体曲线
"pipe"              # 管路
"equipment"         # 设备
"cable"             # 电缆
"assembly"          # 装配
"structure"         # 结构
"volume"            # 体积
"curved panel"      # 曲面面板
"weld"              # 焊缝
```

### 部件类型（PartType）

```
"panel"             # 面板
"boundary"          # 边界
"stiffener"         # 加强筋
"plate"             # 板件
"bracket"           # 支架
"doubling"          # 加厚板
"hole"              # 孔
"cutout"            # 切口
```

## KcsPanelSchema 类

```python
from KcsPanelSchema import PanelSchema

schema = PanelSchema(panel_name)
```

| 方法 | 说明 |
|------|------|
| `GetStatements()` | 返回 `[(group, statement), ...]` 列表 |
| `GetValue(group, keyword)` | 获取语句中关键字的值 |
| `SetValue(group, keyword, value)` | 设置关键字值并执行 |
| `SplitStatement(stmt)` | 拆分语句为关键字列表 |
| `MergeStatement(stmt)` | 合并关键字列表为语句字符串 |

## KcsUtilPan 工具函数

```python
from KcsUtilPan import getBox, getPlane, getLimitEnds, getUname
```

### getPlane 返回值格式

```python
plane_info = getPlane("JUMBO-BHD122")
# 返回元组：(plane_type, coord, origin_point3D, u_vector, v_vector, w_vector)
# plane_type: 1=X平面, 2=Y平面, 3=Z平面
# coord: 平面坐标值（mm）
# origin_point3D: KcsPoint3D 原点
# u_vector, v_vector, w_vector: KcsVector3D 方向向量
```

### getBox 返回值格式

```python
box = getBox("JUMBO-BHD122")
# 返回 KcsBox 对象（UV坐标系中的最小外接矩形）
# box.MinU, box.MaxU: U 方向范围
# box.MinV, box.MaxV: V 方向范围
```

## KcsHighlightSet — 高亮集合

```python
from KcsHighlightSet import HighlightSet

hs = HighlightSet()
hs.AddGeometry2D(point_or_contour)           # 添加 2D 几何体
hs.AddGeometry3D(point_or_polygon, view_hdl) # 添加 3D 几何体（可指定视图）
hs.AddModel(model)                           # 添加模型
hs.AddSubpicture(view_handle)                # 添加子图
hs.Reset()                                   # 清空

# 使用（在图纸中高亮显示）
kcs_draft.highlight(hs)
```

## 示例脚本位置

```
C:\Tribon\M3\Vitesse\Examples\Hull\
├── kcs_ex_hullpan01.py   # 基本面板操作
├── kcs_ex_hullpan02.py   # 复制、移动、分割、拓扑（368行）
├── kcs_ex_hullpan03.py   # 删除接缝、组操作（79行）
├── kcs_ex_hull_XML.py    # XML 创建船体曲线（375行）
├── kcs_ex_hullcurve1.py  # 船体曲线创建
└── kcs_ex_hull_shellstiff.py  # 外板加强筋
```
