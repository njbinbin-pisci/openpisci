# Tribon M3 Python 钩子脚本参考

钩子脚本是放置在 PYTHONPATH 中的 Python 文件，Tribon 在特定事件发生时自动调用。

---

## 公式钩子（_TBhook_Formula.py）

### 功能
计算 Tribon 中的 `$-values`（公式值），用户可自定义编号 10001–10999 的公式。

### 文件位置
```
C:\Tribon\M3\Projects\M3sp\macro\src\_TBhook_Formula.py
```
或任何在 PYTHONPATH 中的目录。

### 接口函数（签名固定，不可修改）

```python
import kcs_dex, kcs_ui, kcs_util, kcs_assembly, kcs_model
import KcsAssembly, KcsModel

ok = kcs_util.success()

def getFormula(ModelType, ModelName, PartType, PartId, SubPartType, SubPartId,
               ReflCode, FormulaNumber,
               ParNInt,                    # 输入整数参数数量
               ParNRea,                    # 输入实数参数数量
               ParNStr,                    # 输入字符串参数数量
               PI0, PI1, PI2, PI3, PI4, PI5, PI6, PI7, PI8, PI9,  # 输入整数
               PR0, PR1, PR2, PR3, PR4, PR5, PR6, PR7, PR8, PR9,  # 输入实数
               PS0, PS1, PS2, PS3, PS4, PS5, PS6, PS7, PS8, PS9): # 输入字符串
    
    FormulaValue = ''
    
    # 自定义公式逻辑
    if FormulaNumber == 10001:
        # 获取孔磨削信息
        est = "HULL.PLATE('" + ModelName + "').HOLE_GRINDING"
        resp = kcs_dex.extract(est)
        if resp == ok:
            kcs_dex.next_result()
            val = kcs_dex.get_string()
            FormulaValue = '*' if val == "YES" else ''
    
    elif FormulaNumber == 10002:
        # 获取弯曲信息
        est = "HULL.PLATE('" + ModelName + "').FOLDED"
        resp = kcs_dex.extract(est)
        if resp == ok:
            kcs_dex.next_result()
            folded = kcs_dex.get_string()
            FormulaValue = 'F' if folded == "YES" else ''
    
    elif FormulaNumber == 10003:
        # 对称面板零件名合并
        est = "HULL.PLATE('" + ModelName + "').PART_ID.LONG"
        resp = kcs_dex.extract(est)
        if resp == ok:
            kcs_dex.next_result()
            FormulaValue = kcs_dex.get_string()
    
    elif FormulaNumber == 10004:
        # 获取装配工作阶段
        est = "HULL.PLATE('" + ModelName + "').AS_ALL"
        resp = kcs_dex.extract(est)
        if resp == ok:
            kcs_dex.next_result()
            as_all = kcs_dex.get_string()
            # 解析 AS_ALL 获取工作位置
            ass = KcsAssembly.Assembly()
            ass.Name = as_all
            try:
                FormulaValue = ass.GetWorkingLocation()
            except:
                FormulaValue = ''
    
    # 返回完整元组（包含所有必需的返回值）
    return (FormulaValue,
            0,                              # ResNInt（输出整数参数数量）
            0,                              # ResNRea（输出实数参数数量）
            0,                              # ResNStr（输出字符串参数数量）
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # RI0-RI9（输出整数）
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,  # RR0-RR9（输出实数）
            '', '', '', '', '', '', '', '', '', '')  # RS0-RS9（输出字符串）
```

### 内置辅助函数

```python
def getIntegerValue(est):
    """提取整数值"""
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 1:
            return kcs_dex.get_int()
    return 0

def getRealValue(est):
    """提取实数值"""
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 2:
            return kcs_dex.get_real()
    return 0.0

def getStringValue(est):
    """提取字符串值"""
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 3:
            return kcs_dex.get_string()
    return ''

def getCompInd(ModelName, DexPartType, PartId, SubDexPartType, SubPartId, ReflCode):
    """通过组件 ID 查找索引"""
    est = "HULL.PANEL('" + ModelName + "')." + DexPartType + "(*).COMP_ID"
    res = kcs_dex.extract(est)
    if res == ok:
        i = 1
        while True:
            typ = kcs_dex.next_result()
            if typ == 0:
                break
            val = kcs_dex.get_string()
            if val == str(PartId):
                return i
            i += 1
    return -1
```

### 预定义公式编号

| 编号 | 功能 |
|------|------|
| 10000 | 测试示例 |
| 10001 | 板件孔磨削（`HOLE_GRINDING`） → `*` 或空 |
| 10002 | 板件弯曲类型（F/H/S/G/B/Z） |
| 10003 | 对称面板零件名合并（`PART_ID.LONG`） |
| 10004 | 装配工作阶段（`AS_ALL` + `GetWorkingLocation()`） |
| 5000 | 带扩展输入输出的示例 |
| 5001 | 法语→英语词典翻译 |

---

## 零件命名钩子（_TBhook_CustPartName.py）

### 功能
在 Tribon 按规则生成零件名后被调用，允许修改最终名称。

### 接口函数（签名固定）

```python
def getPartName(Project, Assembly, Block, Module, System, Drawing, Location,
                PositionName, PositionNo, BracketPositionNo, SymmetryCode,
                BuiltProfile, GPS1, GPS2, GPS3, GPS4,
                TribonPartName, StoringCode, RulePartName):
    """
    参数说明：
    - Project:          项目名
    - Assembly:         装配名
    - Block:            分段名
    - Module:           模块名
    - System:           系统名
    - Drawing:          图纸名
    - Location:         位置
    - PositionName:     位置名
    - PositionNo:       位置号
    - BracketPositionNo: 支架位置号
    - SymmetryCode:     对称代码
    - BuiltProfile:     1=腹板部分，2=翼板部分
    - GPS1-4:           通用字符串参数
    - TribonPartName:   Tribon 生成的零件名
    - StoringCode:      存储代码
    - RulePartName:     按规则生成的原始零件名
    
    返回：
    - CustPartName:     自定义零件名（返回空字符串则使用 RulePartName）
    """
    CustPartName = ''
    
    # 示例：当零件名最后一段以 'A' 开头后跟数字时，抑制位置号
    # 输入: "121-BK40A-A35"  →  输出: "121-BK40A-A"
    parts = RulePartName.split('-')
    if parts and len(parts[-1]) > 1:
        last = parts[-1]
        if last[0] == 'A' and last[1:].isdigit():
            CustPartName = '-'.join(parts[:-1]) + '-A'
    
    return CustPartName
```

---

## 注释配置钩子（_TBhook_ConfigNote.py）

### 功能
为图纸中的各类对象（管路、设备、结构等）提供自定义注释数据。

### 接口函数

```python
import kcs_dex, kcs_util
from KcsConfNoteRec import ReferenceSymbol, Symbol, Text, TextInSymbol

ok = kcs_util.success()

def getNoteName(NoteNo):
    """返回注释名称"""
    names = {1: "Plate Note", 2: "Profile Note", 3: "Bracket Note"}
    return names.get(NoteNo, "")

def getNoteChar(NoteNo):
    """返回注释字符（用于图例）"""
    chars = {1: "P", 2: "F", 3: "B"}
    return chars.get(NoteNo, "")

def getNoteFilter(NoteNo, FilterNo):
    """返回注释过滤条件"""
    # FilterNo=1: 模型类型过滤
    # FilterNo=2: 属性过滤
    return ""

def getNoteData(ItemNo):
    """
    返回注释数据列表
    ItemNo: 当前处理的对象编号
    返回: [注释记录列表]
    """
    records = []
    # 创建文字注释
    txt = Text()
    txt.text = "注释内容"
    txt.x = 0.0
    txt.y = 0.0
    records.append(txt)
    return records

def setNoteData(NoteNo, Model, ...):
    """主注释数据填充函数"""
    pass
```

### KcsConfNoteRec 类

```python
from KcsConfNoteRec import ReferenceSymbol, Symbol, Text, TextInSymbol

# 参考符号
ref = ReferenceSymbol()
ref.symbol_name = "符号名"
ref.x = 0.0
ref.y = 0.0

# 自由符号
sym = Symbol()
sym.symbol_name = "符号名"
sym.x = 0.0
sym.y = 0.0
sym.scale = 1.0

# 自由文本
txt = Text()
txt.text = "文字内容"
txt.x = 0.0
txt.y = 0.0
txt.height = 3.0

# 符号内文本
tis = TextInSymbol()
tis.text = "文字"
tis.symbol_name = "符号名"
tis.field_no = 1
```

---

## 官方文档参考

- `C:\Tribon\M3\Documentation\TBhook_Formula_py.txt` — 公式钩子完整示例
- `C:\Tribon\M3\Documentation\TBhook_CustPartName_py.txt` — 零件命名钩子示例
- `C:\Tribon\M3\Documentation\TBhook_ConfigNote.txt` — 注释配置钩子示例
- `C:\Tribon\M3\Documentation\Customisation_guide.chm` — 定制指南
