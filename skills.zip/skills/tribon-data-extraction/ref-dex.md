# Tribon M3 数据抽取（DEX）完整参考

数据抽取是 Tribon M3 最核心的编程接口，支持从船体、管路、设备、电缆等模型中提取任意属性。

---

## 接口方式

### 方式一：COM 接口（TBDex.TBDex）— 推荐

通过 PowerShell（32位）调用：

```powershell
$dex = New-Object -ComObject 'TBDex.TBDex'

# 执行查询
$dex.DoDataExtraction("HULL.PANEL(*).NAME")

# 获取第一个结果
$val = $dex.GetValue()

# 获取完整结果树（String[] 数组）
$tree = $dex.GetResTree()

# 单位转换（公制→英制）
$imperial = $dex.ConvertToImperial($value, "mm", 2)
```

**GetResTree 返回格式**：`String[]` 数组，包含路径节点和值，例如：
```
["HULL", "", "PANEL", "JUMBO-BHD122", "NAME", "", "", ...]
```

### 方式二：VBA/Excel 接口

```vba
Private dd1 As TBDex
Set dd1 = New TBDex

dd1.DoDataExtraction "HULL.PAN('50A'*).PLATE(1:10).THICKNESS"
val1 = dd1.GetValue
extr1 = dd1.GetResTree  ' 返回路径数组

' 遍历结果
Do While TypeName(val1) <> "Boolean"
    ' 处理 val1
    val1 = dd1.GetValue
Loop
```

### 方式三：Python kcs_dex 模块（Vitesse 内部）

```python
import kcs_dex
import kcs_util

ok = kcs_util.success()

# 执行抽取
res = kcs_dex.extract("HULL.PLATE('ES123-2').THICKNESS")

if res == ok:
    typ = kcs_dex.next_result()
    if typ == 1:    # 整数
        value = kcs_dex.get_int()
    elif typ == 2:  # 实数
        value = kcs_dex.get_real()
    elif typ == 3:  # 字符串
        value = kcs_dex.get_string()
    print "结果:", value
```

**结果类型代码**：
- `1` = 整数
- `2` = 实数（浮点数）
- `3` = 字符串
- `4` = 实数列表

### 方式四：宏语言（GML）

```
EXTRACTION,E,STR;       # 定义抽取表达式
GET/RANGE=(PROJECT,E);  # 获取范围
GET/EXTRACT=(WEIGHT,E,PROJ,PIPNAME,,);  # 获取具体值
```

---

## 表达式语法

### 基本结构

```
MODULE.OBJECT_TYPE('NAME').ATTRIBUTE
MODULE.OBJECT_TYPE(INDEX).ATTRIBUTE
MODULE.OBJECT_TYPE('WILDCARD*').SUB_OBJECT(RANGE).ATTRIBUTE
```

### 通配符

| 语法 | 说明 |
|------|------|
| `*` | 匹配任意字符 |
| `'50A'*` | 匹配所有以 `50A` 开头的名称 |
| `(*)` | 匹配所有对象 |

### 索引范围

| 语法 | 说明 |
|------|------|
| `(1)` | 第 1 个 |
| `(1:10)` | 第 1 到第 10 个 |
| `(*)` | 所有 |

---

## 模块和对象类型

### HULL — 船体模块

#### 面板（PANEL / PAN）

```
HULL.PANEL('面板名').属性
HULL.PAN('面板名').属性
```

| 属性 | 类型 | 说明 |
|------|------|------|
| `NAME` | 字符串 | 面板名称 |
| `THICKNESS` | 实数 | 厚度（mm） |
| `MATERIAL` | 字符串 | 材料 |
| `AREA` | 实数 | 面积（mm²） |
| `WEIGHT` | 实数 | 重量（kg） |
| `BLOCK` | 字符串 | 所属分段 |
| `SYMMETRY` | 整数 | 对称代码（0=左右对称，1=中心线，12=仅右舷） |
| `USER_ATTRIBUTE(i)` | 字符串 | 用户自定义属性第 i 个 |

#### 板件（PLATE / PLA）

```
HULL.PANEL('面板名').PLATE(索引).属性
HULL.PANEL('面板名').PLA(索引).属性
HULL.PLATE('板件名').属性
```

| 属性 | 类型 | 说明 |
|------|------|------|
| `NAME` | 字符串 | 板件名称 |
| `THICKNESS` | 实数 | 厚度（mm） |
| `MATERIAL` | 字符串 | 材料 |
| `AREA` | 实数 | 面积（mm²） |
| `WEIGHT` | 实数 | 重量（kg） |
| `COMP_ID` | 字符串 | 组件 ID |
| `PART_ID.LONG` | 字符串 | 零件 ID（长格式） |
| `HOLE_GRINDING` | 字符串 | 孔磨削（YES/NO） |
| `FOLDED` | 字符串 | 是否弯折（YES/NO） |
| `BENT` | 字符串 | 弯曲类型 |
| `CORRUGATION` | 字符串 | 波纹类型 |
| `KNUCKLED` | 字符串 | 折角类型 |
| `CURVED` | 字符串 | 曲面类型 |
| `ASSPART` | 字符串 | 装配零件 |
| `AS_ALL` | 字符串 | 所有装配信息 |

#### 加强筋（STIFFENER / STIF / STI）

```
HULL.PANEL('面板名').STIFFENER(索引).属性
HULL.PANEL('面板名').STI(索引).属性
HULL.PAN(TB*).STI(1:27).END(1:2).CUT.PAR
```

| 属性 | 说明 |
|------|------|
| `NAME` | 加强筋名称 |
| `TYPE` | 型材类型 |
| `END(1:2).CUT.PAR` | 端部切割参数 |

#### 边界（BOUNDARY）

```
HULL.PANEL('面板名').BOUNDARY(索引).属性
```

---

### PIPE — 管路模块

```
PIPE('管路名').PIPMODEL('模型名').属性
PIPE('DS4').PIPMODEL('P'*).NAME
```

| 对象类型 | 说明 |
|----------|------|
| `PIPMODEL` | 管路模型 |
| `PIPSPOOL` | 管路卷 |
| `CON` | 连接件 |

| 属性 | 说明 |
|------|------|
| `NAME` | 名称 |
| `GEN_PROP.WEIGHT` | 通用属性-重量 |
| `NOMINAL` | 公称直径 |

**示例**：
```
PIPE('300').PIPSPOOL('M4-SA1-A').GEN_PROP.WEIGHT
PIPE('DS4').PIPMODEL('P'*).NAME
COMP('MainC').PIPE.CON(1:2).NOMINAL
```

---

### EQUIP — 设备模块

```
EQUIP.ITEM('设备名').属性
EQUIP.ITEM(RNG).DRAWING(NDR).USAGECODE
```

| 属性 | 说明 |
|------|------|
| `NAME` | 设备名称 |
| `DRAWING(N).USAGECODE` | 图纸使用代码 |
| `DRAWING(N).POSITION` | 图纸位置 |
| `DRAWING(N).NAME` | 图纸名称 |

---

### COMP — 设备/组件模块

```
COMP('组件名').属性
COMP('MainC').PIPE.CON(1:2).NOMINAL
```

---

### CABLE — 电缆模块

```
CABLE.ITEM('电缆名').属性
```

---

## 完整示例

### 获取所有面板名称

```powershell
$dex = New-Object -ComObject 'TBDex.TBDex'
$dex.DoDataExtraction("HULL.PANEL(*).NAME")
$tree = $dex.GetResTree()
# tree 是 String[] 数组，包含路径和值
Write-Output ("面板数量相关: " + $tree.Length)
```

### 获取指定面板的板件厚度（VBA 风格）

```vba
dd1.DoDataExtraction "HULL.PAN('50A'*).PLATE(1:10).THICKNESS"
val1 = dd1.GetValue
Do While TypeName(val1) <> "Boolean"
    Cells(row, col) = val1
    val1 = dd1.GetValue
    row = row + 1
Loop
```

### Python kcs_dex 辅助函数（来自 KcsUtilDexPan.py）

```python
import kcs_dex, kcs_util

def getIntegerValue(est):
    ok = kcs_util.success()
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 1:
            return kcs_dex.get_int()
    return None

def getRealValue(est):
    ok = kcs_util.success()
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 2:
            return kcs_dex.get_real()
    return None

def getStringValue(est):
    ok = kcs_util.success()
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 3:
            return kcs_dex.get_string()
    return None

def getReaListValue(est):
    ok = kcs_util.success()
    res = kcs_dex.extract(est)
    if res == ok:
        typ = kcs_dex.next_result()
        if typ == 4:
            values = []
            i = 0
            while True:
                try:
                    v = kcs_dex.get_indexedreal(i)
                    values.append(v)
                    i += 1
                except:
                    break
            return values
    return None

def getCompInd(Model, CompType, Comp, SubCompType, SubComp):
    """通过组件编号查找数据抽取索引"""
    est = "HULL.PANEL('" + Model.Name + "')." + CompType + "(*).COMP_ID"
    ok = kcs_util.success()
    res = kcs_dex.extract(est)
    if res == ok:
        i = 1
        while True:
            typ = kcs_dex.next_result()
            if typ == 0:
                break
            val = kcs_dex.get_string()
            if val == str(Comp):
                return i
            i += 1
    return -1
```

### 宏语言数据抽取（MACRO DEX）

```
MACRO,DEXJ;
   ASSIGN,PIPNAME,'M4-SA1-A';
   ASSIGN,STR,
      'PIPE(''300'').PIPSPOOL(''M4-SA1-A'').' !!
      'GEN_PROP.WEIGHT';
   EXTRACTION,J,STR;
   GET/RANGE=(PROJECT,J);
   PUT,PROJECT;
   LOOP,PROJ,PROJECT;
      GET/EXTRACT=(WEIGHT,J,PROJ,PIPNAME,,);
      PUT,WEIGHT;
   ENDLOOP;
ENDMACRO;
```

---

## 官方文档参考

- `C:\Tribon\M3\Documentation\Data_Extraction.chm` — 数据抽取完整手册
- `C:\Tribon\M3\Documentation\basic_vba_example.txt` — VBA 示例
- `C:\Tribon\M3\Documentation\basic_macro_dex.txt` — 宏语言示例
- `C:\Tribon\M3\Documentation\basic_macro_dexj.txt` — 管路数据抽取宏示例
- `C:\Tribon\M3\Documentation\DatExt_*.xls` — 各模块数据抽取 Excel 模板
- `C:\Tribon\M3\Documentation\Developers_Toolkit_M3SP5.pdf` — 开发者工具包
