# Tribon M3 Vitesse Python API 参考

Vitesse 是 Tribon M3 的内嵌 Python 2.3 脚本环境，提供 `kcs_*` 系列模块用于操作船舶设计数据。

> **重要**：`kcs_*` 模块是 C 扩展（.pyd），只能在 Tribon 进程内部运行，不能独立调用。

---

## kcs_* 核心模块

### kcs_util — 工具函数

```python
import kcs_util

kcs_util.success()          # 返回成功状态码
kcs_util.ok()               # 同 success()
kcs_util.failure()          # 返回失败状态码
kcs_util.coord_to_pos(coord, axis)  # 坐标转位置（frp/lyp/lzp）
```

---

### kcs_dex — 数据抽取

```python
import kcs_dex

# 执行抽取
res = kcs_dex.extract(expression_string)

# 获取结果类型（循环调用直到返回0）
typ = kcs_dex.next_result()
# 返回值：0=无更多结果, 1=整数, 2=实数, 3=字符串, 4=实数列表

# 获取值
val = kcs_dex.get_int()           # 获取整数
val = kcs_dex.get_real()          # 获取实数
val = kcs_dex.get_string()        # 获取字符串
val = kcs_dex.get_indexedreal(i)  # 获取实数列表第i个元素
```

---

### kcs_ui — 用户界面

```python
import kcs_ui

# 字符串输入
result = kcs_ui.string_req("提示文字")
# 返回 (status, value)，status == kcs_util.ok() 时成功

# 字符串选择（从列表）
result = kcs_ui.string_select("标题", "提示", "默认值", ["选项1", "选项2"])

# 菜单选择
result = kcs_ui.choice_select("标题", "提示", ["操作1", "操作2", "退出"])

# 消息确认
kcs_ui.message_confirm("消息内容")

# 调试消息
kcs_ui.message_debug("调试信息")

# 模型信息
kcs_ui.model_info(model)

# 发送命令（通过命令ID）
kcs_ui.command_send(command_id)

# 指示模型（在图纸中点选）
result = kcs_ui.model_indicate("提示", model_types)

# 指示点
result = kcs_ui.point2D_req("提示")
result = kcs_ui.point3D_req("提示")
```

---

### kcs_hullpan — 船体面板操作

```python
import kcs_hullpan

# 激活面板
kcs_hullpan.pan_activate(panelname)

# 存储面板
kcs_hullpan.pan_store()              # 存储所有
kcs_hullpan.pan_store(panelname)     # 存储指定

# 跳过面板
kcs_hullpan.pan_skip(panelname)      # 跳过指定
kcs_hullpan.pan_skip()               # 跳过所有

# 删除面板
kcs_hullpan.pan_delete(panelname)

# 列出已激活面板
panels = kcs_hullpan.pan_list_active()  # 返回面板名列表

# 复制面板
kcs_hullpan.pan_copy(source_name, target_name, options)

# 移动面板
kcs_hullpan.pan_move(panelname, options)

# 重建面板
kcs_hullpan.pan_recreate(panelname)

# 分割面板
kcs_hullpan.pan_split(panelname, plane, new_name, block, sym_code)

# 拓扑查询
kcs_hullpan.pan_topology(panelname, topology_type)

# 删除接缝
kcs_hullpan.pan_remove_seam(panelname, seam_id)

# 组操作
kcs_hullpan.pan_group_delete(panelname, group_dict)
kcs_hullpan.pan_group_divide(panelname, group_dict, models)

# 加强筋分割
kcs_hullpan.pan_sti_split_by_model(stiffener_id, options)
kcs_hullpan.pan_sti_split_by_plane(stiffener_id, options)
```

---

### kcs_chm — 曲面船体模型

```python
import kcs_chm

# 通过 XML 创建船体曲线
kcs_chm.run_XML(xml_file_path)

# 导出 XML
kcs_chm.output_XML(output_path)

# 加强筋操作
kcs_chm.stiffener_split(stiffener, plane)
kcs_chm.stiffener_to_profdb(stiffener)
kcs_chm.stiffener_combine(stiffeners)
kcs_chm.recreate(model)
```

---

### kcs_struct — 结构操作

```python
import kcs_struct

# 创建结构
struct = kcs_struct.struct_new(structName, modName, color)

# 板件操作
plateComp = kcs_struct.pseudoname_plate(thickness)
platePart = kcs_struct.plate_new_contour2D(comp, oriPoint, normal, rotation, contour)

# 孔操作
holeComp = kcs_struct.pseudoname_hole(width, height)
holePart = kcs_struct.hole_new(comp, platePart, oriPoint, rotation)

# 型材操作
profileComp = kcs_struct.pseudoname_profile('F', 200, 10)  # 扁钢 200x10
profilePart = kcs_struct.profile_new_2point3D(comp, startPoint, endPoint, rotation)

# 端切
profileEndcut = kcs_struct.profile_endcut(profilePart, point, endcutType, angle)

# 保存
kcs_struct.struct_save()

# 错误信息
print kcs_struct.error
```

---

### kcs_equip — 设备操作

```python
import kcs_equip

# 创建设备
kcs_equip.equip_new(name, module)

# 激活设备
kcs_equip.equip_activate(name)

# 检查是否存在
exists = kcs_equip.equip_exist(name)

# 设置属性
kcs_equip.equip_component_set(component)
kcs_equip.equip_room_set(room)
kcs_equip.equip_alias_set(alias)
kcs_equip.equip_description_set(description)

# 保存
kcs_equip.equip_save()

# 错误信息
print kcs_equip.error
```

---

### kcs_model — 模型操作

```python
import kcs_model

# 查找与船体接触的模型
contact_models = kcs_model.model_hull_contact(model)

# 模型操作（参见 kcs_ex_model*.py 示例）
```

---

### kcs_assembly — 装配操作

```python
import kcs_assembly

# 装配操作（与 KcsAssembly 类配合使用）
```

---

### kcs_vol — 体积操作

```python
import kcs_vol

# 新建体积
kcs_vol.vol_new(name)

# 关闭体积
kcs_vol.vol_close(name)

# 打开体积
kcs_vol.vol_open(name)

# 保存体积
kcs_vol.vol_save(name)

# 另存为
kcs_vol.vol_save_as(name, new_name)

# 检查是否存在
exists = kcs_vol.vol_exists(name)

# 删除体积
kcs_vol.vol_delete(name)
```

---

### kcs_weld — 焊接操作

```python
import kcs_weld

# 焊接计算
weld_table = kcs_weld.weld_calculation(assembly_name)

# 获取焊接表
# weld_table 包含所有焊缝信息（KcsWeldTable 对象）
```

---

### kcs_cable / kcs_cway — 电缆和桥架

```python
import kcs_cable, kcs_cway

# 创建电缆
kcs_cable.cable_new(name)

# 激活电缆
kcs_cable.cable_activate(name)

# 设置组件
kcs_cable.cable_component_set(component)

# 连接设备
kcs_cable.cable_equipment_connect(equipment_name, end)

# 保存
kcs_cable.cable_save()

# 桥架操作
kcs_cway.cway_new(name, ...)
```

---

## Kcs* 类库（C:\Tribon\M3\Vitesse\Lib\）

### KcsModel — 模型类

```python
from KcsModel import Model

m = Model()
m.Type = "plane panel"   # 模型类型
m.Name = "JUMBO-BHD122"  # 模型名称
m.PartType = "plate"     # 部件类型
m.PartId = 1             # 部件 ID
m.SubPartType = ""       # 子部件类型
m.SubPartId = 0          # 子部件 ID
m.ReflCode = 0           # 反射代码（0=未反射，1=已反射，2=两者）
```

**模型类型（Type）枚举**：
```
"plane panel"       # 平面面板
"hull curve"        # 船体曲线
"pipe"              # 管路
"equipment"         # 设备
"cable"             # 电缆
"assembly"          # 装配
"structure"         # 结构
"volume"            # 体积
"curved panel"      # 曲面面板
"weld"              # 焊缝
```

**部件类型（PartType）枚举**：
```
"panel"             # 面板
"boundary"          # 边界
"stiffener"         # 加强筋
"plate"             # 板件
"bracket"           # 支架
"doubling"          # 加厚板
"hole"              # 孔
"cutout"            # 切口
```

---

### KcsAssembly — 装配类

```python
from KcsAssembly import Assembly

a = Assembly()
a.Name = "BLOCK-001"
a.Descrip = "描述"
a.BuildStrat = "A&B&C&D&E&F"  # 6段构建策略，& 分隔
a.PlanningUnit = "PU1"
a.Type = "block"
a.WorkingLocation = "WL1"
a.Destination = "DEST1"
a.DesignStatus = "APPROVED"
a.ProductionStatus = "IN_PRODUCTION"
a.AssemblyOrientation = "UpRight"
a.Level = 50  # 0-100
```

**装配方向枚举**：
```
"UpRight"           # 正置
"Upside Down"       # 倒置
"Fore Down"         # 艏朝下
"Aft Down"          # 艉朝下
"Portside Down"     # 左舷朝下
"Starboard Down"    # 右舷朝下
"Automatic"         # 自动
"Specific Panel"    # 特定面板
```

---

### KcsPoint3D / KcsPoint2D — 坐标点

```python
from KcsPoint3D import Point3D
from KcsPoint2D import Point2D

p3 = Point3D(1000.0, 2000.0, 3000.0)
p3.SetCoordinates(x, y, z)

p2 = Point2D(100.0, 200.0)
p2.X = 150.0
p2.Y = 250.0
```

---

### KcsVector3D / KcsVector2D — 向量

```python
from KcsVector3D import Vector3D
from KcsVector2D import Vector2D

v3 = Vector3D(1.0, 0.0, 0.0)  # X 方向单位向量
v3.SetComponents(x, y, z)
```

---

### KcsContour2D — 2D 轮廓

```python
from KcsContour2D import Contour2D
from KcsPoint2D import Point2D

start = Point2D(0.0, 0.0)
cont = Contour2D(start)

# 添加直线段
cont.AddLine(Point2D(1000.0, 0.0))
cont.AddLine(Point2D(1000.0, 1000.0))

# 添加圆弧（终点，半径）
cont.AddArc(Point2D(0.0, 1000.0), 250.0)

# 闭合
cont.AddLine(Point2D(0.0, 0.0))
```

---

### KcsHighlightSet — 高亮集合

```python
from KcsHighlightSet import HighlightSet

hs = HighlightSet()
hs.AddGeometry2D(point_or_contour)
hs.AddGeometry3D(point_or_polygon, view_handle)
hs.AddModel(model)
hs.AddSubpicture(view_handle)
hs.Reset()
```

---

### KcsElementHandle — 元素句柄

```python
from KcsElementHandle import ElementHandle

handle = ElementHandle()
handle.Handle = 12345  # 整数句柄
```

---

### KcsObjectCriteria — 对象查询条件

```python
from KcsObjectCriteria import ObjectCriteria

crit = ObjectCriteria()
crit.Name = "PANEL*"
crit.Code1 = 1
crit.Code2 = 2
crit.Size = 100  # 支持 ">100", ">=100" 等
```

---

### KcsPanelSchema — 面板 Schema 操作

```python
from KcsPanelSchema import PanelSchema

schema = PanelSchema(panel_name)
val = schema.GetValue("GROUP", "KEYWORD")
schema.SetValue("GROUP", "KEYWORD", "VALUE")
statements = schema.GetStatements()  # 返回 [(group, statement), ...]
```

---

### KcsUtilDexPan — 数据抽取工具（来自 Lib）

```python
from KcsUtilDexPan import getIntegerValue, getRealValue, getStringValue, getReaListValue, getCompInd

thickness = getRealValue("HULL.PLATE('ES123-2').THICKNESS")
material = getStringValue("HULL.PLATE('ES123-2').MATERIAL")
comp_index = getCompInd(model, "PLATE", comp_id, "", 0)
```

---

### KcsUtilPan — 面板工具（来自 Lib）

```python
from KcsUtilPan import getBox, getPlane, getLimitEnds, getUname

box = getBox(panel_name)           # 获取面板包围盒（UV坐标）
plane_info = getPlane(panel_name)  # 获取面板平面信息
ends = getLimitEnds(panel_name, limit_name)  # 获取边界端点
unique_name = getUname(block, panel_gen)     # 生成唯一面板名
```

---

## 触发器（Trigger）机制

触发器在 Tribon 执行特定操作前（pre）或后（post）自动调用 Python 脚本。

### 触发器脚本位置
```
C:\Tribon\M3\Vitesse\Trigger\
```

### 触发器框架

```python
# kcs_ex_trig01.py 框架
def pre_trigger(TriggerName, *args):
    """操作前触发，可修改输入参数或中止操作"""
    # 返回 (kcs_util.ok(), args)    — 继续执行
    # 返回 (kcs_util.override(), new_args) — 覆盖参数
    # 返回 (kcs_util.abort(), reason)     — 中止操作
    return (kcs_util.ok(),) + args

def post_trigger(TriggerName, *args):
    """操作后触发"""
    pass
```

### 关键触发器文件

| 文件 | 触发时机 |
|------|---------|
| `trig_draft_init.py` | Drafting 应用初始化时（加载菜单和 AddIns） |
| `trig_dm_parts_list.py` | 零件清单生成前后 |
| `trig_draft_popup_menu.py` | 右键菜单显示时 |
| `trig_ap_parts_list_create.py` | 装配计划零件清单创建时 |
| `trig_tm_prediction.py` | 时间预测时 |

---

## GUI 定制（kcs_gui_basic_design.py）

通过命令 ID 发送 GUI 命令：

```python
import kcs_gui_basic_design as gui

# 文件操作
kcs_ui.command_send(gui.file_new())        # 33036
kcs_ui.command_send(gui.file_open())       # 33035
kcs_ui.command_send(gui.file_save())       # 33037

# 运行 Vitesse 脚本
kcs_ui.command_send(gui.tools_vitesse_run_script())  # 33503

# 分析
kcs_ui.command_send(gui.analysis_wcog())             # 33718
kcs_ui.command_send(gui.analysis_weld_calculation()) # 33716

# XML 导入/导出
kcs_ui.command_send(gui.xml_import_hull_steel_import())  # 33101
kcs_ui.command_send(gui.xml_export_hull_steel_export())  # 33099
```

---

## 官方示例脚本位置

```
C:\Tribon\M3\Vitesse\Examples\
├── Hull\           # 船体面板、曲线、加强筋示例
├── Equipment\      # 设备操作示例
├── Cable\          # 电缆和桥架示例
├── Vol\            # 体积操作示例
├── Weld\           # 焊接计算示例
├── Customer_Def_Attr\ # 用户自定义属性示例
└── Customisable_GUI\  # GUI 定制示例
```
