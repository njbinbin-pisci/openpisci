---
name: tribon-tasks
description: Tribon M3 任务操作手册入口。覆盖船舶设计中的所有常用任务：项目管理、数据查询、装配BOM、图纸打印、面板建模、模型查找与操作、脚本执行、数据传输。
version: "1.1"
tools:
  - com_invoke
  - shell
  - file_list
  - file_read
  - file_write
platform:
  - windows
triggers:
  - tribon
  - 船体设计
  - 船舶建模
  - vitesse
  - TBDex
  - kcs_hullpan
---

# Tribon M3 任务操作手册

## 使用方法

根据用户的任务，用 `file_read` 加载对应的操作文件，然后按文件中的步骤执行。

**所有 COM 调用必须使用 `com_invoke` 工具，参数 `arch: "x86"`（Tribon 全部是 32 位 COM）。**

---

## COM对象注册与验证

### 重要发现与解决方案

1. **COM对象注册问题**：如果COM对象无法创建（错误：Class not registered），需要注册Tribon的DLL文件。
2. **TBRuntime.TBEnvironment正确用法**：该对象使用`GetDefaultValue()`方法获取环境变量，而不是`GetVariable()`。
3. **完整的COM组件列表**：需要注册多个DLL才能确保所有COM对象可用。

**详细指南**：请参考[COM对象注册与故障排除指南](com-registration-guide.md)

### COM对象注册脚本（简化版）

在`C:\Tribon\M3\Bin\`目录下创建`register_all_com.bat`文件，内容如下：

```batch
@echo off
echo 正在注册Tribon COM组件...
echo.

regsvr32 /s tbps.dll
regsvr32 /s tbpsps.dll
regsvr32 /s tbruntime.dll
regsvr32 /s tbdbaccess.dll
regsvr32 /s TbDotComOnClient.dll
regsvr32 /s tbprojectselect.dll
regsvr32 /s tbrmtfile.dll
regsvr32 /s tbbatchjob.dll
regsvr32 /s tbruntime.dll
regsvr32 /s tbhtmlhelp.dll
regsvr32 /s ModImport.dll
regsvr32 /s TbCompInproc.dll
regsvr32 /s tdmadmin.dll
regsvr32 /s TbComDlg32.dll
regsvr32 /s TbPrintSrv.dll
regsvr32 /s TbQuerySrv.dll
regsvr32 /s TbDocumentSrv.dll
regsvr32 /s TbModelViewer.dll
regsvr32 /s tbexpimp.dll
regsvr32 /s tbcommon.dll
regsvr32 /s TbMORMgr.dll
regsvr32 /s tbtransferps.dll
regsvr32 /s TbCadInterface.dll
regsvr32 /s TBPresentCollisions.dll
regsvr32 /s TbModelCalculations.dll
regsvr32 /s TbGenPostprocessor.dll
regsvr32 /s tbtmsrv.dll
regsvr32 /s TbGraph.ocx
regsvr32 /s calcx_m3.dll

echo.
echo 正在注册EXE组件...
echo.

tbjlaunch.exe /regserver
tbdexint.exe /regserver
tbtransfer.exe /regserver
TbPartsListGen.exe /regserver

echo.
echo Tribon COM组件注册完成！
pause
```

**注意**：需要以管理员权限运行此脚本。

### 关键COM对象验证

使用以下PowerShell脚本验证COM对象是否可用：

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$comObjects = @(
    'Tbprojectselect.TBProjSelect',
    'TBDex.TBDex',
    'TBPrintSrv.TBApplication',
    'TBPrintSrv.FindDrawings',
    'TBPrintSrv.PrintJob',
    'TbPartsListGen.TbAssPartsListGen',
    'TBModelCalculations.TBModelCalc',
    'TBJob.TBJob',
    'TBRuntime.TBEnvironment'
)

foreach ($progId in $comObjects) {
    try {
        $obj = New-Object -ComObject $progId
        Write-Output "✅ $progId - 创建成功"
    } catch {
        Write-Output "❌ $progId - 创建失败: $_"
    }
}
```

### TBRuntime.TBEnvironment正确使用方法

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env = New-Object -ComObject 'TBRuntime.TBEnvironment'

# 正确：使用GetDefaultValue方法
$project = $env.GetDefaultValue("PROJECT")

# 错误：不要使用GetVariable方法（不存在）
# $project = $env.GetVariable("PROJECT")  # ❌ 会报错
```

---

## 任务索引

### 项目管理
用户说：*有哪些项目、当前项目、切换项目、项目目录、数据库服务是否运行*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-projects.md")`

---

### 数据查询（DEX）与属性读写
用户说：*有哪些面板、面板的板件厚度/材料/重量、管路重量、设备列表、查询某个属性、读写用户自定义属性、批量设置属性*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-query.md")`

---

### 装配与零件清单（BOM）
用户说：*装配重量、零件清单、BOM、子装配、零件数量、设计状态、制造状态、计划日期*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-assembly.md")`

---

### 图纸打印
用户说：*打印图纸、批量打印、打印船体图纸、PDF输出、查找图纸*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-drawing.md")`

---

### 面板建模与操作
用户说：*创建面板、复制面板到另一位置、批量移动面板、批量删除某类面板、修改面板坐标参数、创建结构/板件/型材/孔、批量创建船体曲线、批量创建设备*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-modeling.md")`

---

### 脚本、宏与钩子开发
用户说：*运行 Python 脚本、执行宏、编写钩子、自定义公式、自定义零件名、GML 宏、批量报表*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-scripting.md")`

---

### 模型查找、放置与属性操作
用户说：*查找某类模型、按名称前缀搜索、获取设备组件名、设备放置到坐标、平移/旋转设备、批量移动设备、删除设备、修改模型描述/状态/计划单元、碰撞检查、查找相邻结构、遍历装配树、读写装配属性*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-model-ops.md")`

---

### 数据传输与姊妹船
用户说：*复制项目数据、姊妹船、项目间传输、导入导出、检查点、断点续传*

→ 加载：`file_read("C:\\Users\\zzz\\AppData\\Roaming\\com.pisci.desktop\\skills\\tribon-tasks\\task-transfer.md")`