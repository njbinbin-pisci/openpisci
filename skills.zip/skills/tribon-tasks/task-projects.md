# Tribon M3 — 项目管理任务

> 所有 COM 调用：`com_invoke` 工具，参数 `arch: "x86"`

---

## 任务：列出所有可用项目

Tribon 项目 = `C:\Tribon\M3\Projects\` 下的每个子目录。

```json
// file_list 工具
{ "path": "C:\\Tribon\\M3\\Projects", "recursive": false }
```

需要同时显示项目是否有数据库时，改用 shell：

```powershell
# shell, interpreter=powershell
Get-ChildItem "C:\Tribon\M3\Projects" -Directory |
  Select-Object Name,
    @{N='有数据库';E={Test-Path (Join-Path $_.FullName 'db')}},
    @{N='最后修改';E={$_.LastWriteTime.ToString('yyyy-MM-dd')}} |
  Format-Table -AutoSize
```

---

## 任务：查询当前选中的项目

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
Write-Output ("项目:   " + $ps.Project)
Write-Output ("子项目: " + $ps.SubProject)
Write-Output ("服务器: " + $ps.Host)
```

返回空 = 尚未选择项目。

---

## 任务：切换到指定项目（如"切换到 M3sp"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")   # ← 将 M3sp 替换为目标项目名
Write-Output ("已切换: " + $ps.Project + " / " + $ps.SubProject)
```

- 项目名**区分大小写**
- 第三个参数（子项目）留 `""` 使用默认子项目
- 此操作需要数据库服务（`ea312.exe`）运行，否则会挂起

---

## 任务：查询当前项目的路径和环境变量

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env = New-Object -ComObject 'TBRuntime.TBEnvironment'
foreach ($v in @("SB_PROJECT","SB_PROJ","SBGD_DB","SBGD_DEF","SBGD_DATA","SBGD_PRINT")) {
    try   { Write-Output ($v + " = " + $env.GetDefaultValue($v)) }
    catch { Write-Output ($v + " = (未设置)") }
}
```

---

## 任务：查看项目目录结构（如"M3sp 项目里有什么"）

```powershell
# shell, interpreter=powershell
$proj = "M3sp"   # ← 替换为项目名
Get-ChildItem "C:\Tribon\M3\Projects\$proj" -Directory |
  ForEach-Object {
    $count = (Get-ChildItem $_.FullName -File -EA SilentlyContinue).Count
    "$($_.Name)/  ($count 个文件)"
  }
```

---

## 任务：检查 Tribon 数据库服务是否运行

```powershell
# shell, interpreter=powershell
$proc = Get-Process ea312 -ErrorAction SilentlyContinue
if ($proc) { "✓ 数据库服务运行中 (PID $($proc.Id))" }
else       { "✗ 数据库服务未运行 — COM 数据操作将挂起，请先启动 Tribon" }
```

---

## 任务：设置项目环境（为后续脚本/宏执行准备）

```bat
rem shell, interpreter=cmd
cd C:\Tribon\M3\Bin
tbsetenv.exe M3sp
tbprintenv.exe
```

将 `M3sp` 替换为目标项目名。
