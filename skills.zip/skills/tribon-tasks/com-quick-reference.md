# Tribon COM对象快速参考

## 核心COM对象

| COM对象 | 功能 | 关键方法 |
|---------|------|----------|
| `Tbprojectselect.TBProjSelect` | 项目管理 | `Project`, `SubProject`, `Host`, `SelectProjectBatch()` |
| `TBRuntime.TBEnvironment` | 环境变量 | `GetDefaultValue()`, `List()`, `Remove()`, `Store()` |
| `TBDex.TBDex` | 数据查询 | `DoDataExtraction()`, `GetValue()` |
| `TBPrintSrv.TBApplication` | 图纸打印 | `Print()`, `FindDrawings()` |
| `TbPartsListGen.TbAssPartsListGen` | 零件清单 | `GeneratePartsList()` |
| `TBModelCalculations.TBModelCalc` | 模型计算 | `Calculate()` |
| `TBJob.TBJob` | 作业管理 | `RunJob()` |

## 快速验证脚本

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 测试关键COM对象
$testObjects = @('Tbprojectselect.TBProjSelect', 'TBRuntime.TBEnvironment', 'TBDex.TBDex')
foreach ($obj in $testObjects) {
    try {
        New-Object -ComObject $obj | Out-Null
        Write-Output "✅ $obj"
    } catch {
        Write-Output "❌ $obj - 需要注册"
    }
}
```

## 常见问题速查

### Q1: COM对象创建失败 "Class not registered"
**A**: 运行注册脚本：`C:\Tribon\M3\Bin\register_all_com.bat`（管理员权限）

### Q2: TBRuntime.TBEnvironment方法调用失败
**A**: 使用`GetDefaultValue("变量名")`而不是`GetVariable("变量名")`

### Q3: 所有COM对象都需要32位架构
**A**: 所有调用必须使用`arch: "x86"`参数

### Q4: 数据库服务未运行
**A**: 检查`ea312.exe`进程是否运行，否则COM操作会挂起

## 环境变量示例

```powershell
$env = New-Object -ComObject 'TBRuntime.TBEnvironment'
$vars = @("SB_PROJECT","SB_PROJ","SBGD_DB","SBGD_DEF","SBGD_DATA","SBGD_PRINT")
foreach ($v in $vars) {
    try { "$v = $($env.GetDefaultValue($v))" }
    catch { "$v = (未设置)" }
}
```

## 项目切换示例

```powershell
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")  # 切换到M3sp项目
Write-Output "当前项目: $($ps.Project)"
```

## 紧急修复步骤

1. **下载注册脚本**：
   ```powershell
   # 从技能目录复制
   Copy-Item "C:\Users\zzz\AppData\Roaming\com.pisci.desktop\skills\tribon-tasks\register_all_com.bat" "C:\Tribon\M3\Bin\"
   ```

2. **运行注册**：
   - 右键点击`register_all_com.bat`
   - 选择"以管理员身份运行"
   - 等待完成

3. **验证修复**：
   ```powershell
   # 运行验证脚本
   & "C:\Users\zzz\AppData\Roaming\com.pisci.desktop\skills\tribon-tasks\verify_com_objects.ps1"
   ```

## 联系支持

如果问题仍未解决：
1. 检查`C:\Tribon\M3\Bin\`目录是否存在
2. 确认Tribon M3已正确安装
3. 参考完整指南：`com-registration-guide.md`
4. 联系系统管理员或Tribon技术支持