# Tribon COM对象验证脚本
# 版本: 1.1
# 日期: 2026-03-23

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Tribon COM对象验证脚本" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查Tribon目录
if (-not (Test-Path "C:\Tribon\M3\Bin\")) {
    Write-Host "错误：Tribon M3未安装或路径不正确！" -ForegroundColor Red
    Write-Host "请确认Tribon M3已安装在C:\Tribon\M3" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Tribon目录存在：C:\Tribon\M3\Bin\" -ForegroundColor Green
Write-Host ""

# 关键COM对象列表
$comObjects = @(
    @{Name = 'Tbprojectselect.TBProjSelect'; Description = '项目管理'},
    @{Name = 'TBRuntime.TBEnvironment'; Description = '环境变量管理'},
    @{Name = 'TBDex.TBDex'; Description = '数据查询'},
    @{Name = 'TBPrintSrv.TBApplication'; Description = '图纸打印'},
    @{Name = 'TBPrintSrv.FindDrawings'; Description = '图纸查找'},
    @{Name = 'TBPrintSrv.PrintJob'; Description = '打印作业'},
    @{Name = 'TbPartsListGen.TbAssPartsListGen'; Description = '零件清单'},
    @{Name = 'TBModelCalculations.TBModelCalc'; Description = '模型计算'},
    @{Name = 'TBJob.TBJob'; Description = '作业管理'}
)

Write-Host "正在验证COM对象..." -ForegroundColor Yellow
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($com in $comObjects) {
    $progId = $com.Name
    $desc = $com.Description
    
    Write-Host "测试: $desc" -NoNewline
    Write-Host " ($progId)" -ForegroundColor Gray -NoNewline
    
    try {
        $obj = New-Object -ComObject $progId -ErrorAction Stop
        Write-Host " ✓ 成功" -ForegroundColor Green
        $successCount++
        
        # 对于TBRuntime.TBEnvironment，测试GetDefaultValue方法
        if ($progId -eq 'TBRuntime.TBEnvironment') {
            try {
                $testValue = $obj.GetDefaultValue("PROJECT")
                Write-Host "   GetDefaultValue('PROJECT') = '$testValue'" -ForegroundColor DarkGray
            } catch {
                Write-Host "   GetDefaultValue方法测试失败（可能未设置变量）" -ForegroundColor DarkYellow
            }
        }
        
        # 对于Tbprojectselect.TBProjSelect，显示当前项目
        if ($progId -eq 'Tbprojectselect.TBProjSelect') {
            Write-Host "   当前项目: '$($obj.Project)'" -ForegroundColor DarkGray
        }
        
    } catch {
        Write-Host " ✗ 失败: $($_.Exception.Message)" -ForegroundColor Red
        $failCount++
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "验证结果汇总" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($failCount -eq 0) {
    Write-Host "✅ 所有COM对象验证成功！" -ForegroundColor Green
    Write-Host "   共测试 $successCount 个对象，全部通过" -ForegroundColor Green
} else {
    Write-Host "⚠️  部分COM对象验证失败" -ForegroundColor Yellow
    Write-Host "   成功: $successCount 个，失败: $failCount 个" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "建议解决方案：" -ForegroundColor Yellow
    Write-Host "1. 以管理员身份运行 register_all_com.bat" -ForegroundColor White
    Write-Host "2. 确保Tribon M3已正确安装" -ForegroundColor White
    Write-Host "3. 检查C:\Tribon\M3\Bin\目录下的DLL文件" -ForegroundColor White
}

Write-Host ""
Write-Host "详细指南请参考：" -ForegroundColor Cyan
Write-Host "- com-registration-guide.md (完整指南)" -ForegroundColor White
Write-Host "- com-quick-reference.md (快速参考)" -ForegroundColor White
Write-Host ""

# 等待用户按键
Write-Host "按任意键退出..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")