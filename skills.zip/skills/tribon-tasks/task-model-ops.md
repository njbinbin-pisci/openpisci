# Tribon M3 — 模型查找与操作任务

> 本文件覆盖：查找/列举各类模型、获取模型名称、设备放置与变换、模型属性读写、碰撞检查等。
>
> **执行方式**：
> - COM 查询（PowerShell）：`com_invoke` 工具，`arch: "x86"`
> - 建模操作（Python）：`file_write` 写脚本 → `com_invoke` 通过 TBJob 执行

---

## 任务：查找项目中所有某类模型（"有哪些设备/管路/结构/面板"）

### 通过 DEX（PowerShell，推荐用于只读查询）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")   # <- 替换项目名
$dex = New-Object -ComObject 'TBDex.TBDex'

# 查所有设备
$dex.DoDataExtraction("EQUIP.ITEM(*).NAME")
$dex.GetResTree() | Where-Object { $_ -ne "" -and $_ -notmatch "^(EQUIP|ITEM|NAME)$" }

# 查所有面板
$dex.DoDataExtraction("HULL.PANEL(*).NAME")
$dex.GetResTree() | Where-Object { $_ -ne "" -and $_ -notmatch "^(HULL|PANEL|NAME)$" }

# 查所有管路模型
$dex.DoDataExtraction("PIPE('*').PIPMODEL('P'*).NAME")
$dex.GetResTree() | Where-Object { $_ -ne "" -and $_ -notmatch "^(PIPE|PIPMODEL|NAME)$" }

# 查所有结构（struct）
$dex.DoDataExtraction("STRUCT.ITEM(*).NAME")
$dex.GetResTree() | Where-Object { $_ -ne "" -and $_ -notmatch "^(STRUCT|ITEM|NAME)$" }
```

---

## 任务：按名称前缀/通配符查找模型（"找所有名字以 BHD 开头的面板"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'

$prefix = "BHD"   # <- 替换前缀
$dex.DoDataExtraction("HULL.PANEL('" + $prefix + "'*).NAME")
$results = $dex.GetResTree() | Where-Object { $_ -like ($prefix + "*") }
Write-Output ("找到 " + $results.Count + " 个匹配面板:")
$results | ForEach-Object { Write-Output ("  " + $_) }
```

---

## 任务：获取模型的完整属性（"BHD122 的所有信息"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'

$panelName = "BHD122"   # <- 替换
# 一次查询多个属性
$dex.DoDataExtraction("HULL.PANEL('" + $panelName + "').PLATE(*).NAME,THICKNESS,MATERIAL,WEIGHT,AREA")
$dex.GetResTree() | ForEach-Object { Write-Output $_ }
```

---

## 任务：获取设备的组件名和位置（"PUMP-001 用的什么组件，在哪里"）

```python
# 写入脚本文件后执行（Vitesse）
import kcs_equip, kcs_dex, kcs_util
import KcsModel

ok = kcs_util.ok()

equip_name = "PUMP-001"   # <- 替换

# 方法1：通过 kcs_equip 激活后读取
kcs_equip.equip_activate(equip_name)

# 获取组件名（通过 DEX）
res = kcs_dex.extract("EQUIP.ITEM('" + equip_name + "').COMPONENT")
if res == ok:
    kcs_dex.next_result()
    comp = kcs_dex.get_string()
    print "组件名:", comp

# 获取描述
res = kcs_dex.extract("EQUIP.ITEM('" + equip_name + "').DESCRIPTION")
if res == ok:
    kcs_dex.next_result()
    desc = kcs_dex.get_string()
    print "描述:", desc

# 获取房间
res = kcs_dex.extract("EQUIP.ITEM('" + equip_name + "').ROOM")
if res == ok:
    kcs_dex.next_result()
    room = kcs_dex.get_string()
    print "房间:", room

kcs_equip.equip_cancel()
```

---

## 任务：将设备放置到指定坐标（"把 PUMP-001 放到 X=5000, Y=3000, Z=2000"）

`kcs_equip.equip_place(origin_point, x_vector, y_vector)` — 已由官方示例 `kcs_ex_equip04.py` 证实。

```python
# 写入脚本文件后执行
import kcs_equip, kcs_util
import KcsPoint3D, KcsVector3D

equip_name = "PUMP-001"   # <- 替换
x = 5000.0   # <- 目标坐标（mm）
y = 3000.0
z = 2000.0

kcs_equip.equip_activate(equip_name)

origin  = KcsPoint3D.Point3D(x, y, z)
x_vec   = KcsVector3D.Vector3D(1.0, 0.0, 0.0)   # X 轴方向（设备朝向）
y_vec   = KcsVector3D.Vector3D(0.0, 1.0, 0.0)   # Y 轴方向

try:
    kcs_equip.equip_place(origin, x_vec, y_vec)
    kcs_equip.equip_save()
    print "已放置: " + equip_name + " 到 (" + str(x) + ", " + str(y) + ", " + str(z) + ")"
except Exception as e:
    print "失败: " + str(kcs_equip.error)
    kcs_equip.equip_cancel()
```

---

## 任务：平移设备到新位置（"把 PUMP-001 沿 X 轴移动 500mm"）

`kcs_equip.equip_transform(Transformation3D)` — 已由官方示例证实。

```python
import kcs_equip, kcs_util
import KcsVector3D, KcsTransformation3D

equip_name = "PUMP-001"   # <- 替换
dx = 500.0   # <- X 方向偏移（mm）
dy = 0.0
dz = 0.0

kcs_equip.equip_activate(equip_name)

trans_vec = KcsVector3D.Vector3D(dx, dy, dz)
transform = KcsTransformation3D.Transformation3D()
transform.Translate(trans_vec)

try:
    kcs_equip.equip_transform(transform)
    kcs_equip.equip_save()
    print "已平移: " + equip_name
except Exception as e:
    print "失败: " + str(kcs_equip.error)
    kcs_equip.equip_cancel()
```

---

## 任务：旋转设备（"把 PUMP-001 绕 Z 轴旋转 90 度"）

```python
import kcs_equip, kcs_util
import KcsPoint3D, KcsVector3D, KcsTransformation3D
import math

equip_name = "PUMP-001"   # <- 替换
angle_deg  = 90.0         # <- 旋转角度（度）

kcs_equip.equip_activate(equip_name)

rot_center = KcsPoint3D.Point3D(0.0, 0.0, 0.0)   # <- 旋转中心
rot_axis   = KcsVector3D.Vector3D(0.0, 0.0, 1.0)  # <- 旋转轴（Z轴）
transform  = KcsTransformation3D.Transformation3D()
transform.Rotate(rot_center, rot_axis, angle_deg)

try:
    kcs_equip.equip_transform(transform)
    kcs_equip.equip_save()
    print "已旋转: " + equip_name + " " + str(angle_deg) + " 度"
except Exception as e:
    print "失败: " + str(kcs_equip.error)
    kcs_equip.equip_cancel()
```

---

## 任务：批量移动一组设备到新坐标（"把所有 PUMP-* 设备沿 X 移动 1000mm"）

```python
import kcs_equip, kcs_dex, kcs_util
import KcsVector3D, KcsTransformation3D

ok = kcs_util.ok()
dx = 1000.0   # <- 偏移量

# 先获取所有匹配设备名
equips = []
res = kcs_dex.extract("EQUIP.ITEM('PUMP'*).NAME")   # <- 修改前缀
if res == ok:
    while True:
        typ = kcs_dex.next_result()
        if typ == 0: break
        if typ == 3: equips.append(kcs_dex.get_string())

print "找到 " + str(len(equips)) + " 个设备"

for name in equips:
    try:
        kcs_equip.equip_activate(name)
        trans_vec = KcsVector3D.Vector3D(dx, 0.0, 0.0)
        transform = KcsTransformation3D.Transformation3D()
        transform.Translate(trans_vec)
        kcs_equip.equip_transform(transform)
        kcs_equip.equip_save()
        print "已移动: " + name
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_equip.error)
        try: kcs_equip.equip_cancel()
        except: pass
```

---

## 任务：删除设备（"删除 PUMP-001"）

```python
import kcs_equip, kcs_util

equip_name = "PUMP-001"   # <- 替换

if kcs_equip.equip_exist(equip_name):
    try:
        kcs_equip.equip_delete(equip_name)
        print "已删除: " + equip_name
    except Exception as e:
        print "失败: " + str(kcs_equip.error)
else:
    print "设备不存在: " + equip_name
```

---

## 任务：修改设备属性（"更新 PUMP-001 的描述和房间"）

```python
import kcs_equip, kcs_util

equip_name  = "PUMP-001"         # <- 替换
new_desc    = "主循环泵 #1"       # <- 新描述
new_room    = "ENGINE_ROOM"       # <- 新房间
new_alias   = "P-001"            # <- 别名（可选）
new_component = "PUMP-COMP-NEW"  # <- 新组件名（可选）

if kcs_equip.equip_exist(equip_name):
    kcs_equip.equip_activate(equip_name)
    try:
        kcs_equip.equip_description_set(new_desc)
        kcs_equip.equip_room_set(new_room)
        if new_alias:
            kcs_equip.equip_alias_set(new_alias)
        if new_component:
            kcs_equip.equip_component_set(new_component)
        kcs_equip.equip_save()
        print "已更新: " + equip_name
    except Exception as e:
        print "失败: " + str(kcs_equip.error)
        kcs_equip.equip_cancel()
```

---

## 任务：读取/修改模型的 TDM 属性（TypeCode、PlanningUnit、描述等）

`kcs_model.model_properties_get/set` 配合 `KcsCommonProperties` 使用 — 已由官方示例 `kcs_ex_model04.py` 证实。

```python
import kcs_model, kcs_util
import KcsModel, KcsCommonProperties

model = KcsModel.Model()
model.Type = "plane panel"   # <- 模型类型（见下方类型表）
model.Name = "BHD122"        # <- 模型名称

# 读取属性
try:
    tdm = kcs_model.model_properties_get(model)
    print "描述:", tdm.GetDescription()
    print "计划单元:", tdm.GetPlanningUnit()
    print "成本代码:", tdm.GetCostCode()
    tc1, tc2, tc3, tc4 = tdm.GetTypeCode()
    print "类型代码:", tc1, tc2, tc3, tc4
    a1, a2, a3, a4 = tdm.GetAlias()
    print "别名:", a1, a2, a3, a4
except Exception as e:
    print "失败: " + str(kcs_model.error)

# 修改属性
try:
    tdm2 = KcsCommonProperties.CommonProperties()
    tdm2.SetDescription("新描述")
    tdm2.SetPlanningUnit("UNIT-A")
    kcs_model.model_properties_set(model, tdm2)
    print "属性已更新"
except Exception as e:
    print "失败: " + str(kcs_model.error)
```

**模型类型字符串对照表**（`model.Type` 的值）：

| 类型 | 字符串 |
|------|--------|
| 平面面板 | `"plane panel"` |
| 曲面面板 | `"curved panel"` |
| 船体曲线 | `"hull curve"` |
| 管路 | `"pipe"` |
| 管路卷 | `"pipe spool"` |
| 设备 | `"equipment"` |
| 电缆槽 | `"cable way"` |
| 电缆 | `"cable"` |
| 结构 | `"struct"` |
| 装配 | `"assembly"` |
| 纵骨 | `"longitudinal"` |
| 横骨 | `"transversal"` |
| 通风 | `"ventilation"` |

---

## 任务：碰撞检查（"BHD122 附近有哪些设备/管路"）

`kcs_model.model_interference_check(model, outfitting_type, distance)` — 已由官方示例 `kcs_ex_model05.py` 证实。

```python
import kcs_model, kcs_util
import KcsModel

model = KcsModel.Model()
model.Type = "plane panel"   # <- 被检查的模型类型
model.Name = "BHD122"        # <- 被检查的模型名

outfitting_type = "equipment"  # <- 检查与哪类模型的碰撞：equipment / pipe / struct / cable / ventilation
distance = 100.0               # <- 检查范围（mm）

try:
    results = kcs_model.model_interference_check(model, outfitting_type, distance)
    if results:
        print "在 " + str(distance) + "mm 范围内找到 " + str(len(results)) + " 个 " + outfitting_type + ":"
        for m in results:
            print "  " + m.Name + " (" + m.Type + ")"
    else:
        print "无碰撞"
except Exception as e:
    print "失败: " + str(kcs_model.error)
```

---

## 任务：查找与面板接触的船体模型（"BHD122 与哪些结构相邻"）

`kcs_model.model_hull_contact(model)` — 已由官方示例 `kcs_ex_model01.py` 证实。

```python
import kcs_model, kcs_util
import KcsModel

model = KcsModel.Model()
model.Type = "plane panel"
model.Name = "BHD122"   # <- 替换

try:
    contacts = kcs_model.model_hull_contact(model)
    if contacts:
        print "与 " + model.Name + " 接触的模型:"
        for m in contacts:
            print "  " + m.Name + " (" + m.Type + ")"
    else:
        print "无接触模型"
except Exception as e:
    print "失败: " + str(kcs_model.error)
```

---

## 任务：修改模型的设计/生产状态（"把 BHD122 的设计状态改为 RELEASED"）

`kcs_model.model_status_set(model, status_type, status_value)` — 已由官方示例 `kcs_ex_model03.py` 证实。

```python
import kcs_model, kcs_util
import KcsModel

model = KcsModel.Model()
model.Type = "plane panel"
model.Name = "BHD122"   # <- 替换

# status_type 常量：
#   kcs_model.kcsSTATTYPE_DESIGN          设计状态
#   kcs_model.kcsSTATTYPE_MANUFACTURING   制造状态
#   kcs_model.kcsSTATTYPE_ASSEMBLY        装配状态
#   kcs_model.kcsSTATTYPE_MATERIAL_CONTROL 材料控制状态

# 先查询可用的状态值
status_type = kcs_model.kcsSTATTYPE_DESIGN
available = kcs_model.status_values_get(status_type)
print "可用设计状态:", available.values()

# 设置状态（status_value 是状态 ID，从 status_values_get 返回的字典的 key 中取）
# 例如：status_value = available.keys()[0]
try:
    kcs_model.model_status_set(model, status_type, "RELEASED")   # <- 替换为实际状态值
    print "状态已更新"
except Exception as e:
    print "失败: " + str(kcs_model.error)
```

---

## 任务：遍历装配树获取所有子装配和零件（"BLOCK-001 的完整层级"）

`kcs_assembly.assembly_sub_get(name)` 和 `kcs_assembly.assembly_model_ref_get(name)` — 已由官方示例 `kcs_ex_ass01.py` 证实。

```python
import kcs_assembly, kcs_util

def list_assembly(name, indent=0):
    pad = "  " * indent
    print pad + "[装配] " + name

    # 获取子装配
    try:
        subs = kcs_assembly.assembly_sub_get(name)
        for username, internal_name in subs:
            list_assembly(internal_name, indent + 1)
    except:
        pass

    # 获取模型引用（零件）
    try:
        models = kcs_assembly.assembly_model_ref_get(name)
        for model in models:
            print pad + "  [零件] " + model.GetName() + " (" + model.GetType() + ")"
    except:
        pass

# 从根装配开始遍历（空字符串 = 根）
try:
    roots = kcs_assembly.assembly_sub_get()
    for username, internal_name in roots:
        list_assembly(internal_name)
except Exception as e:
    print "失败: " + str(kcs_assembly.error)
```

---

## 任务：获取装配的路径名和内部名（"BLOCK-001 的内部标识是什么"）

```python
import kcs_assembly, kcs_util

ass_name = "BLOCK-001"   # <- 替换

# 路径名 -> 内部名
try:
    internal = kcs_assembly.assembly_internal_name_get(ass_name)
    print "内部名:", internal
except:
    print "获取内部名失败:", kcs_assembly.error

# 内部名 -> 路径名
try:
    path = kcs_assembly.assembly_path_name_get(internal)
    print "路径名:", path
except:
    print "获取路径名失败:", kcs_assembly.error

# 获取父装配
try:
    parent_path, parent_internal = kcs_assembly.assembly_parent_get(ass_name)
    print "父装配:", parent_path, "(", parent_internal, ")"
except:
    print "无父装配（已是根）"
```

---

## 任务：读取/修改装配属性（描述、计划日期、状态等）

`kcs_assembly.assembly_properties_get/set` 配合 `KcsAssembly.Assembly` 对象 — 已由官方示例 `kcs_ex_ass01.py` 证实。

```python
import kcs_assembly, kcs_util
import KcsAssembly

ass_name = "BLOCK-001"   # <- 替换

kcs_assembly.assembly_activate(ass_name)
try:
    ass_obj = kcs_assembly.assembly_properties_get()

    # 读取属性
    print "名称:", ass_obj.GetName()
    print "描述:", ass_obj.GetDescription()
    print "类型:", ass_obj.GetType()
    print "设计状态:", ass_obj.GetDesignStatus()
    print "生产状态:", ass_obj.GetProductionStatus()
    print "工作位置:", ass_obj.GetWorkingLocation()
    print "计划单元:", ass_obj.GetPlanningUnit()
    print "目标地:", ass_obj.GetDestination()
    print "估算重量:", ass_obj.GetEstimatedWeight(), "kg"
    cog = ass_obj.GetEstimatedCOG()
    print "估算重心: X=" + str(cog.X) + " Y=" + str(cog.Y) + " Z=" + str(cog.Z)

    # 修改属性
    new_ass = KcsAssembly.Assembly()
    new_ass.SetDescription("新描述")
    new_ass.SetDesignStatus("RELEASED")
    new_ass.SetPlanningUnit("UNIT-B")
    kcs_assembly.assembly_properties_set(new_ass)
    kcs_assembly.assembly_save()
    print "属性已更新"
except Exception as e:
    print "失败: " + str(kcs_assembly.error)
    kcs_assembly.assembly_cancel()
```
