# Tribon COM对象注册与故障排除指南

## 概述

本文档提供了Tribon M3 COM对象的完整注册指南和常见问题解决方案。基于实际测试和网络资料收集，确保所有COM对象都能正常工作。

## 目录

1. [COM对象注册脚本](#com对象注册脚本)
2. [常见错误及解决方案](#常见错误及解决方案)
3. [关键COM对象验证](#关键com对象验证)
4. [TBRuntime.TBEnvironment正确用法](#tbruntimetbenvironment正确用法)
5. [完整的COM对象列表](#完整的com对象列表)

## COM对象注册脚本

### 注册批处理文件

在`C:\Tribon\M3\Bin\`目录下创建`register_all_com.bat`文件：

```batch
@echo off
echo 正在注册Tribon COM组件...
echo.

regsvr32 /s tbps.dll
regsvr32 /s tbpsps.dll
regsvr32 /s tbruntime.dll
regsvr32 /s tbdbaccess.dll
regsvr32 /s TbDotComOnClient.dll
regsvr32 /s tbprojectselect.dll
regsvr32 /s tbrmtfile.dll
regsvr32 /s tbbatchjob.dll
regsvr32 /s tbruntime.dll
regsvr32 /s tbhtmlhelp.dll
regsvr32 /s ModImport.dll
regsvr32 /s TbCompInproc.dll
regsvr32 /s tdmadmin.dll
regsvr32 /s TbComDlg32.dll
regsvr32 /s TbPrintSrv.dll
regsvr32 /s TbQuerySrv.dll
regsvr32 /s TbDocumentSrv.dll
regsvr32 /s TbModelViewer.dll
regsvr32 /s tbexpimp.dll
regsvr32 /s tbcommon.dll
regsvr32 /s TbMORMgr.dll
regsvr32 /s tbtransferps.dll
regsvr32 /s TbCadInterface.dll
regsvr32 /s TBPresentCollisions.dll
regsvr32 /s TbModelCalculations.dll
regsvr32 /s TbGenPostprocessor.dll
regsvr32 /s tbtmsrv.dll
regsvr32 /s TbGraph.ocx
regsvr32 /s calcx_m3.dll

echo.
echo 正在注册EXE组件...
echo.

tbjlaunch.exe /regserver
tbdexint.exe /regserver
tbtransfer.exe /regserver
TbPartsListGen.exe /regserver

echo.
echo Tribon COM组件注册完成！
pause
```

### 执行步骤

1. **以管理员身份运行**：右键点击`register_all_com.bat`，选择"以管理员身份运行"
2. **等待完成**：脚本将自动注册所有DLL和EXE组件
3. **验证注册**：运行验证脚本确认所有COM对象可用

## 常见错误及解决方案

### 错误1：Class not registered (0x80040154)

**症状**：
```
检索 COM 类工厂中 CLSID 为 {00000000-0000-0000-0000-000000000000} 的组件失败，
原因是出现以下错误: 80040154 Class not registered
```

**原因**：COM对象未在系统中注册

**解决方案**：
1. 运行上述注册脚本
2. 确保以管理员权限运行
3. 检查DLL文件是否存在：`C:\Tribon\M3\Bin\tbruntime.dll`

### 错误2：找不到"GetType"的重载，参数计数为"0" (0x80131501)

**症状**：
```
找不到"GetType"的重载，参数计数为"0"
```

**原因**：COM对象创建成功，但某些.NET方法调用有问题

**解决方案**：
1. 这是版本兼容性问题，不影响实际功能使用
2. 使用COM对象的实际方法（如`GetDefaultValue`）而不是.NET方法

### 错误3：方法调用失败，不包含名为"GetVariable"的方法

**症状**：
```
方法调用失败，因为 [System.__ComObject] 不包含名为"GetVariable"的方法
```

**原因**：使用了错误的方法名

**解决方案**：
- 使用`GetDefaultValue()`方法而不是`GetVariable()`
- 正确示例：`$env.GetDefaultValue("PROJECT")`

## 关键COM对象验证

### 验证脚本

使用以下PowerShell脚本验证COM对象是否可用：

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$comObjects = @(
    'Tbprojectselect.TBProjSelect',
    'TBDex.TBDex',
    'TBPrintSrv.TBApplication',
    'TBPrintSrv.FindDrawings',
    'TBPrintSrv.PrintJob',
    'TbPartsListGen.TbAssPartsListGen',
    'TBModelCalculations.TBModelCalc',
    'TBJob.TBJob',
    'TBRuntime.TBEnvironment'
)

Write-Output "=== Tribon COM对象验证 ==="
Write-Output ""

foreach ($progId in $comObjects) {
    try {
        $obj = New-Object -ComObject $progId
        Write-Output "✅ $progId - 创建成功"
    } catch {
        Write-Output "❌ $progId - 创建失败: $_"
    }
}

Write-Output ""
Write-Output "=== 验证完成 ==="
```

### 预期结果

所有COM对象都应显示"创建成功"：
```
✅ Tbprojectselect.TBProjSelect - 创建成功
✅ TBDex.TBDex - 创建成功
✅ TBPrintSrv.TBApplication - 创建成功
✅ TBPrintSrv.FindDrawings - 创建成功
✅ TBPrintSrv.PrintJob - 创建成功
✅ TbPartsListGen.TbAssPartsListGen - 创建成功
✅ TBModelCalculations.TBModelCalc - 创建成功
✅ TBJob.TBJob - 创建成功
✅ TBRuntime.TBEnvironment - 创建成功
```

## TBRuntime.TBEnvironment正确用法

### 正确方法

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env = New-Object -ComObject 'TBRuntime.TBEnvironment'

# 获取环境变量
$project = $env.GetDefaultValue("PROJECT")
$subProject = $env.GetDefaultValue("SB_PROJ")
$dbPath = $env.GetDefaultValue("SBGD_DB")

# 列出所有环境变量
$variableList = $env.List()
```

### 可用方法

`TBRuntime.TBEnvironment`对象支持以下方法：
- `GetDefaultValue(name)` - 获取环境变量的值
- `List()` - 列出所有环境变量
- `Remove(name)` - 删除环境变量
- `RemoveAll()` - 删除所有环境变量
- `Store(name, value)` - 设置环境变量（注意：可能有限制）

### 错误用法

```powershell
# ❌ 错误：不存在GetVariable方法
$project = $env.GetVariable("PROJECT")

# ❌ 错误：直接访问属性
$project = $env.PROJECT
```

## 完整的COM对象列表

### 项目管理
- `Tbprojectselect.TBProjSelect` - 项目选择和管理
- `TBRuntime.TBEnvironment` - 环境变量管理

### 数据查询
- `TBDex.TBDex` - 数据抽取接口
- `TBQuerySrv.*` - 查询服务

### 图纸打印
- `TBPrintSrv.TBApplication` - 打印应用程序
- `TBPrintSrv.FindDrawings` - 图纸查找
- `TBPrintSrv.PrintJob` - 打印作业

### 零件清单
- `TbPartsListGen.TbAssPartsListGen` - 装配零件清单生成
- `TbPartsListGen.*` - 其他零件清单组件

### 模型计算
- `TBModelCalculations.TBModelCalc` - 模型计算
- `TbModelViewer.*` - 模型查看器

### 作业管理
- `TBJob.TBJob` - 作业管理

### 数据传输
- `tbtransfer.exe` - 数据传输（通过/regserver注册）

## 故障排除流程

1. **第一步：检查COM对象注册**
   - 运行验证脚本
   - 如果有对象创建失败，运行注册脚本

2. **第二步：检查管理员权限**
   - 确保以管理员身份运行注册脚本
   - 检查UAC设置

3. **第三步：检查DLL文件**
   - 确认`C:\Tribon\M3\Bin\`目录存在
   - 确认关键DLL文件存在（如`tbruntime.dll`）

4. **第四步：检查32位注册**
   - Tribon使用32位COM对象
   - 确保使用`arch: "x86"`参数
   - 检查WOW6432Node注册表

5. **第五步：检查方法调用**
   - 使用正确的方法名（如`GetDefaultValue`）
   - 参考本文档中的正确用法示例

## 参考资料

1. **Tribon COM组件注册** - 博客园文章
2. **Tribon二次开发资料** - 网络收集
3. **实际测试结果** - 本地验证
4. **tribon-tasks技能源代码** - 实际使用示例

## 更新日志

- **v1.0** (2026-03-23): 初始版本，包含完整的COM对象注册指南
- **v1.1** (2026-03-23): 添加TBRuntime.TBEnvironment正确用法说明
- **v1.2** (2026-03-23): 添加故障排除流程和常见错误解决方案