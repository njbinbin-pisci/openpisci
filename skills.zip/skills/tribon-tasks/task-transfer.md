# Tribon M3 — 数据传输与姊妹船任务

> 所有 COM 调用：`com_invoke` 工具，参数 `arch: "x86"`
> 传输操作需要 Tribon 数据库服务（`ea312.exe`）运行

---

## 任务：将项目数据导出（"把 M3sp 的数据导出"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("M3sp")   # ← 替换为源项目名

$ts.Label = "导出批次-001"
$ts.Comment = "从 M3sp 导出"
$ts.ShowConsole = $true

$ts.DumpCollection()
Write-Output "导出完成"
```

---

## 任务：将数据从一个项目传输到另一个项目（"把 M3sp 的数据传到 M3sp2"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'

# 打开源项目
$ts.OpenProject("M3sp")   # ← 替换为源项目名

# 配置传输
$ts.Label = "传输-M3sp-to-M3sp2"
$ts.Comment = "项目间数据传输"
$ts.ShowConsole = $true

# 获取传输选项（可进一步配置要传输的内容）
$opts = $ts.GetOptions()
$sel  = $ts.GetSelection()

# 执行传输
$ts.DumpCollection()
Write-Output "传输完成"
```

---

## 任务：姊妹船复制（"以 M3sp 为模板创建姊妹船"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("M3sp")   # ← 源项目（模板船）

# 启用姊妹船模式
$ts.SisterShipMode = $true

# 查看图纸类型映射（姊妹船需要配置图纸编号映射）
$mapping = $ts.GetDrawingTypeMapping()
Write-Output ("图纸类型映射: " + $mapping)

$sisterInfo = $ts.GetSisterShip()
Write-Output ("姊妹船配置: " + $sisterInfo)

# 执行复制
$ts.DumpCollection()
Write-Output "姊妹船复制完成"
```

---

## 任务：启用检查点（断点续传大型传输）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("M3sp")

# 启用检查点（每 100 个对象保存一次进度）
$ts.EnableCheckpoints = $true
$ts.CheckpointInterval = 100
$ts.AutoDeleteCheckpoints = $false   # 完成后保留检查点

$ts.DumpCollection()
Write-Output "传输完成（含检查点）"
```

---

## 任务：从上次中断处恢复传输（"上次传输中断了，继续"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("M3sp")

# 查看最后一个检查点
$lastCp = $ts.GetLastCheckpointInfo()
Write-Output ("最后检查点: " + $lastCp)

# 从最后检查点恢复
$ts.ResumeLastCheckpoint()
Write-Output "已从检查点恢复并继续传输"
```

---

## 任务：查看传输归档信息

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ts = New-Object -ComObject 'Tbtransfer.TBTransferSet'
$ts.OpenProject("M3sp")
$archive = $ts.GetArchive()
Write-Output ("归档信息: " + $archive)
$cpInfo = $ts.GetCheckpointInfo()
Write-Output ("检查点信息: " + $cpInfo)
```
