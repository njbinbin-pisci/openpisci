# Tribon M3 — 建模操作任务

> 建模操作通过 **Vitesse Python 脚本**（`kcs_*` 模块）实现，脚本必须在 Tribon 进程内运行。
>
> **执行流程**：用 `file_write` 工具写脚本 → 用 `com_invoke` 通过 TBJob 执行
>
> **⚠ 能力边界**（已通过本机官方示例验证）：
> - `kcs_hullpan`：支持面板级别的 **复制/移动/分割/删除**，操作对象是整个面板
> - `kcs_struct`：支持 **创建** 板件/型材/孔，以及修改零件组件引用和型材端点；**不支持修改已有板件的厚度**（需删除重建）
> - `KcsPanelSchema`：可通过 `SetValue(group_int, keyword, value)` 修改面板 Schema 关键字（如平面坐标），是**修改面板参数的主要途径**
> - `kcs_equip`：支持创建/激活设备，**不支持批量操作**（需循环调用）
> - DEX 只读：数据抽取接口**只能读取，不能写入**属性

---

## 任务：将面板复制到另一个位置（"把 BHD122 复制一份到 X=6000"）

`pan_copy` 需要 `CopyPanOptions` 对象（继承自 `MovePanOptions`），`pan_move` 需要 `MovePanOptions` 对象。

脚本内容（写入 `pisci_task.py`）：
```python
import kcs_hullpan
from KcsCopyPanOptions import CopyPanOptions

src = "BHD122"      # <- 源面板名
dst = "BHD122-CP"   # <- 新面板名
block = ""          # <- 目标分段名（空=同分段）

# 第一步：配置复制选项
opt = CopyPanOptions()
opt.SetNameMapping({src: dst})   # 旧名 -> 新名 的映射
if block:
    opt.SetBlockName(block)

# 第二步：复制面板（在原位置创建副本）
kcs_hullpan.pan_copy(src, opt)

# 第三步：移动副本到目标坐标
from KcsMovePanOptions import MovePanOptions
move_opt = MovePanOptions()
move_opt.SetPrincipalPlane(MovePanOptions.X, 0, "6000")  # X轴，绝对坐标 6000mm
kcs_hullpan.pan_move(dst, move_opt)

kcs_hullpan.pan_store(dst)
print "完成：" + dst + " 已复制到 X=6000"
```

执行：
```powershell
# com_invoke, arch=x86
$job = New-Object -ComObject 'TBJob.TBJob'
$job.Create("VITESSE", "M3sp")
$job.CommandLine = "C:\Tribon\M3\Bin\python.exe C:\Tribon\M3\Projects\M3sp\macro\src\pisci_task.py"
$job.Run()
```

---

## 任务：批量复制一组面板（"把 BHD121 到 BHD125 都复制一份，名字加 -NEW"）

```python
import kcs_hullpan
from KcsCopyPanOptions import CopyPanOptions

panels = ["BHD121", "BHD122", "BHD123", "BHD124", "BHD125"]  # <- 替换
suffix = "-NEW"

for src in panels:
    dst = src + suffix
    try:
        opt = CopyPanOptions()
        opt.SetNameMapping({src: dst})
        kcs_hullpan.pan_copy(src, opt)
        kcs_hullpan.pan_store(dst)
        print "已复制: " + src + " -> " + dst
    except Exception as e:
        print "失败: " + src + " - " + str(kcs_hullpan.error)
```

---

## 任务：批量移动面板（"把所有 BHD* 面板沿 X 轴移动 500mm"）

```python
import kcs_dex, kcs_util, kcs_hullpan
from KcsMovePanOptions import MovePanOptions

ok = kcs_util.success()
offset = 500   # <- 偏移量（mm），相对移动，字符串形式传入

# 先用 DEX 获取所有匹配面板名
panels = []
res = kcs_dex.extract("HULL.PANEL('BHD'*).NAME")   # <- 修改前缀
if res == ok:
    while True:
        typ = kcs_dex.next_result()
        if typ == 0: break
        if typ == 3: panels.append(kcs_dex.get_string())

print "找到 " + str(len(panels)) + " 个面板"

for name in panels:
    try:
        move_opt = MovePanOptions()
        # SetPrincipalPlane(coord_axis, relative_flag, coord_value_str)
        # coord_axis: 1=X, 2=Y, 3=Z; relative_flag: 1=相对, 0=绝对
        move_opt.SetPrincipalPlane(MovePanOptions.X, 1, str(offset))
        kcs_hullpan.pan_move(name, move_opt)
        kcs_hullpan.pan_store(name)
        print "已移动: " + name
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_hullpan.error)
```

---

## 任务：批量删除某类面板（"删除所有名称含 TEMP 的面板"）

```python
import kcs_dex, kcs_util, kcs_hullpan

ok = kcs_util.success()
keyword = "TEMP"   # <- 匹配关键字

panels = []
res = kcs_dex.extract("HULL.PANEL(*).NAME")
if res == ok:
    while True:
        typ = kcs_dex.next_result()
        if typ == 0: break
        if typ == 3:
            name = kcs_dex.get_string()
            if keyword in name:
                panels.append(name)

print "将删除 " + str(len(panels)) + " 个面板: " + str(panels)

for name in panels:
    try:
        kcs_hullpan.pan_delete(name)
        print "已删除: " + name
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_hullpan.error)
```

---

## 任务：修改面板的平面坐标（"把 BHD122 的 X 坐标改为 5500"）

面板的定义参数通过 `KcsPanelSchema` 读写。`SetValue` 的第一个参数是**组号（整数）**，需先用 `GetStatements()` 查看当前面板的语句组。

```python
from KcsPanelSchema import PanelSchema
import kcs_hullpan

panel_name = "BHD122"   # <- 替换
new_coord  = "5500"     # <- 新坐标（字符串）

kcs_hullpan.pan_activate(panel_name)
schema = PanelSchema(panel_name)

# 第一步：查看当前所有 Schema 语句，找到 PLANE 语句的组号
stmts = schema.GetStatements()
print "当前 Schema:"
for grp, stmt in stmts:
    print "  [" + str(grp) + "] " + stmt

# 第二步：修改 PLANE 语句中的坐标关键字
# 假设 PLANE 语句在组号 1（需根据上面输出确认实际组号）
# 关键字名称：X 平面面板用 "X"，Y 平面用 "Y"，Z 平面用 "Z"
plane_group = 1   # <- 根据 GetStatements() 输出确认
schema.SetValue(plane_group, "X", new_coord)   # SetValue 会自动调用 stmt_exec_single

kcs_hullpan.pan_recreate(panel_name)   # 重建面板使修改生效
kcs_hullpan.pan_store(panel_name)
print "完成：" + panel_name + " 坐标已更新为 X=" + new_coord
```

---

## 任务：批量修改一组面板的坐标（"把 FR10 到 FR20 的肋骨面板间距统一改为 600mm"）

```python
from KcsPanelSchema import PanelSchema
import kcs_hullpan

# 定义面板名 -> 新坐标的映射
panel_coords = {
    "FR010": "6000",
    "FR011": "6600",
    "FR012": "7200",
    "FR013": "7800",
    # <- 按实际填写
}

# 注意：plane_group 是 PLANE 语句在该面板 Schema 中的组号
# 对于同类型面板通常相同，但建议先对一个面板调用 GetStatements() 确认
plane_group = 1   # <- 根据实际情况调整

for name, coord in panel_coords.items():
    try:
        kcs_hullpan.pan_activate(name)
        schema = PanelSchema(name)
        schema.SetValue(plane_group, "X", coord)
        kcs_hullpan.pan_recreate(name)
        kcs_hullpan.pan_store(name)
        print "已更新: " + name + " -> X=" + coord
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_hullpan.error)
```

---

## 任务：删除面板上的某个孔组（"删除 BHD122 上减轻孔组"）

`pan_group_delete(panel_name, group_id)` 的第二个参数是**整数组 ID**，需先通过 `GetStatements()` 或 DEX 查询确认。

```python
import kcs_hullpan
from KcsPanelSchema import PanelSchema

panel_name = "BHD122"   # <- 替换

kcs_hullpan.pan_activate(panel_name)
schema = PanelSchema(panel_name)

# 第一步：列出所有语句组，找到目标孔组的组 ID
stmts = schema.GetStatements()
print "当前 Schema 组:"
for grp, stmt in stmts:
    print "  [" + str(grp) + "] " + stmt[:80]

# 第二步：删除指定组（group_id 为整数）
# 例如：减轻孔组的组 ID 为 5（需根据上面输出确认）
target_group_id = 5   # <- 根据 GetStatements() 输出确认
try:
    kcs_hullpan.pan_group_delete(panel_name, target_group_id)
    kcs_hullpan.pan_store(panel_name)
    print "已删除组 " + str(target_group_id)
except Exception as e:
    print "失败: " + str(kcs_hullpan.error)
```

---

## 任务：分割面板（"把 DECK01 沿 X=15000 分成两块"）

```python
import kcs_hullpan
import KcsPoint3D, KcsVector3D, KcsPlane3D
from KcsSplitPanOptions import SplitPanOptions

panel_name = "DECK01"   # <- 源面板名
new_name1  = "DECK01-A" # <- 分割后面板1
new_name2  = "DECK01-B" # <- 分割后面板2
block1     = ""         # <- 分段名（空=同分段）
block2     = ""
side1      = "S"        # <- 对称代码
side2      = "S"

# 定义切割平面（X=15000，法线沿 X 轴）
origin = KcsPoint3D.Point3D(15000, 0, 0)
normal = KcsVector3D.Vector3D(1, 0, 0)
plane  = KcsPlane3D.Plane3D(origin, normal)

opt = SplitPanOptions()
opt.SetCuttingPlane(plane)
opt.AddPanelMapping(new_name1, block1, side1)
opt.AddPanelMapping(new_name2, block2, side2)

kcs_hullpan.pan_split(panel_name, opt)
print "已分割: " + panel_name + " -> " + new_name1 + ", " + new_name2
```

---

## 任务：修改结构件的组件引用（"把 STR-001 中的板件改用 P#16 组件"）

`kcs_struct.part_component(part_id, component_name)` 可修改已有板件/型材的组件引用（即材料/规格）。

```python
import kcs_struct

# part_id 是整数，需通过 DEX 或 kcs_draft.model_identify() 获取
# 这里假设已知 part_id
part_id = 12345   # <- 替换为实际 PartId
new_component = "P#16"   # <- 新组件名（板件厚度规格）

try:
    kcs_struct.part_component(part_id, new_component)
    print "已更新组件: PartId=" + str(part_id) + " -> " + new_component
except Exception as e:
    print "失败: " + str(kcs_struct.error)
```

---

## 任务：修改型材端点（"把 STR-001 中的型材 PartId=678 延长到新端点"）

```python
import kcs_struct
import KcsPoint3D

part_id = 678   # <- 替换
new_p1 = KcsPoint3D.Point3D(0.0, 0.0, 0.0)      # <- 新起点
new_p2 = KcsPoint3D.Point3D(2000.0, 0.0, 0.0)   # <- 新终点

try:
    kcs_struct.profile_endpoints(part_id, new_p1, new_p2)
    print "已更新型材端点: PartId=" + str(part_id)
except Exception as e:
    print "失败: " + str(kcs_struct.error)
```

---

## 任务：创建新结构（板件 + 型材 + 孔）

```python
import kcs_struct
import KcsPoint3D, KcsVector3D, KcsPoint2D, KcsContour2D

struct_name = "STR-001"   # <- 替换
mod_name    = "MODULE-A"  # <- 替换

struct = kcs_struct.struct_new(struct_name, mod_name, 'White')

# 创建板件（厚度 12mm，1000x800 矩形）
# 组件名格式：P#厚度（mm）
plateComp = "P#12"
origin    = KcsPoint3D.Point3D(0.0, 0.0, 0.0)
normal    = KcsVector3D.Vector3D(0.0, 0.0, 1.0)
rotation  = KcsVector3D.Vector3D(1.0, 0.0, 0.0)

pt = KcsPoint2D.Point2D(0.0, 0.0)
cont = KcsContour2D.Contour2D(pt)
pt.X = 1000.0; cont.AddLine(pt)
pt.Y = 800.0;  cont.AddLine(pt)
pt.X = 0.0;    cont.AddLine(pt)
pt.Y = 0.0;    cont.AddLine(pt)

plate = kcs_struct.plate_new_contour2D(plateComp, origin, normal, rotation, cont)

# 创建标准孔（组件名格式：H#宽*高*偏移）
holeComp   = "H#200*150*50"
holeCenter = KcsPoint3D.Point3D(400.0, 300.0, 0.0)
holeRotV   = KcsVector3D.Vector3D(1.0, 0.0, 0.0)
kcs_struct.hole_new(holeComp, plate, holeCenter, holeRotV)

# 创建型材（L 型钢 100x120x8x10，沿 Y 轴）
profComp = "L#100*120*8*10"
startPt  = KcsPoint3D.Point3D(0.0, 400.0, 0.0)
endPt    = KcsPoint3D.Point3D(1000.0, 400.0, 0.0)
kcs_struct.profile_new_2point3D(profComp, startPt, endPt, rotation)

kcs_struct.struct_save()
print "结构 " + struct_name + " 创建完成"
```

---

## 任务：批量创建设备（"批量创建 10 台泵，命名为 PUMP-001 到 PUMP-010"）

```python
import kcs_equip

module    = "MAIN_ENGINE"   # <- 所属模块
component = "PUMP-COMP"     # <- 组件名
count     = 10              # <- 数量

for i in range(1, count + 1):
    name = "PUMP-" + str(i).zfill(3)
    try:
        if not kcs_equip.equip_exist(name):
            kcs_equip.equip_new(name, module)
            kcs_equip.equip_component_set(component)
            kcs_equip.equip_description_set("主泵 " + str(i))
            kcs_equip.equip_save()
            print "已创建: " + name
        else:
            print "已存在，跳过: " + name
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_equip.error)
```

---

## 注意事项

- Python 版本为 **2.3**，使用旧式语法：`print "text"`（无括号）、`except Exception, e:`
- 脚本路径不能含中文或空格
- 需要 Tribon 应用（`sj700.exe`）运行才能执行 `kcs_*` 操作
- `pan_recreate` 会重新计算面板几何，修改 Schema 后必须调用
- `CopyPanOptions` 继承自 `MovePanOptions`，`SetPrincipalPlane(axis, relative, value_str)` 中 axis: 1=X, 2=Y, 3=Z
- DEX 只能**读取**数据，不能通过 DEX 修改属性
- `pan_group_delete` 的第二个参数是**整数组 ID**，不是字符串名称
- `KcsPanelSchema.SetValue` 的第一个参数是**整数组号**，不是语句名称字符串
