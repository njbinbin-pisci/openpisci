# Tribon M3 — 数据查询任务（DEX）

> 所有 COM 调用：`com_invoke` 工具，参数 `arch: "x86"`
> **执行任何查询前必须先选择项目**（见下方"前置步骤"）

---

## 前置步骤：选择项目

> **重要**：`SelectProjectBatch` 需要 **Tribon 数据库服务**（`tbship.exe`）正在运行。
> 如果报 "Project group not found" 或 "Project selection failed"，
> 说明 Tribon 服务未启动，需要先运行 `tbsetenv.exe M3sp` 初始化环境，
> 或通过 Tribon M3 桌面快捷方式启动完整 Tribon 环境后再执行 COM 查询。
>
> **无需 Tribon 运行的替代方案**：`TBDex.TBDex` 在某些情况下可直接使用，
> 无需先调用 `SelectProjectBatch`（取决于环境变量是否已由 `tbsetenv.exe` 设置）。

每次查询前先执行（将 `M3sp` 替换为实际项目名）：

```powershell
# com_invoke, arch=x86
# 方式1：先用 shell 工具运行 tbsetenv.exe 设置环境，再执行 COM 查询
# shell: cd C:\Tribon\M3\Bin && tbsetenv.exe M3sp

# 方式2：直接尝试（如果 Tribon 服务已运行）
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
```

后续代码直接使用 `$dex`，无需重复创建。

**如果 SelectProjectBatch 失败，直接跳过，尝试：**
```powershell
# com_invoke, arch=x86
$dex = New-Object -ComObject 'TBDex.TBDex'
$dex.DoDataExtraction("HULL.PANEL(*).NAME")
$dex.GetResTree()
```

---

## 任务：列出项目中所有面板（"有哪些面板"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$dex.DoDataExtraction("HULL.PANEL(*).NAME")
$tree = $dex.GetResTree()
$panels = $tree | Where-Object { $_ -ne "" -and $_ -notmatch "^(HULL|PANEL|NAME)$" }
Write-Output ("共 " + $panels.Count + " 个面板:")
$panels | ForEach-Object { Write-Output $_ }
```

---

## 任务：查询面板的板件厚度（"BHD122 的板件厚度"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$panelName = "BHD122"   # <- 替换为目标面板名
$dex.DoDataExtraction("HULL.PANEL('" + $panelName + "').PLATE(*).THICKNESS")
$tree = $dex.GetResTree()
$values = $tree | Where-Object { $_ -match '^\d+\.?\d*$' }
Write-Output ("面板 $panelName 的板件厚度 (mm):")
$values | ForEach-Object { Write-Output ("  " + $_ + " mm") }
```

---

## 任务：查询面板的板件材料（"BHD122 用什么材料"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$panelName = "BHD122"   # <- 替换
$dex.DoDataExtraction("HULL.PANEL('" + $panelName + "').PLATE(*).MATERIAL")
$tree = $dex.GetResTree()
$mats = $tree | Where-Object { $_ -ne "" -and $_ -notmatch "^(HULL|PANEL|PLATE|MATERIAL)$" }
$mats | Sort-Object -Unique | ForEach-Object { Write-Output $_ }
```

---

## 任务：查询面板的板件重量（"BHD122 各板件重量"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$panelName = "BHD122"   # <- 替换
$dex.DoDataExtraction("HULL.PANEL('" + $panelName + "').PLATE(*).WEIGHT")
$tree = $dex.GetResTree()
$weights = $tree | Where-Object { $_ -match '^\d+\.?\d*$' }
$total = ($weights | Measure-Object -Sum).Sum
Write-Output ("面板 $panelName 板件重量:")
$weights | ForEach-Object { Write-Output ("  " + $_ + " kg") }
Write-Output ("合计: $total kg")
```

---

## 任务：批量查询所有面板的板件信息（"汇总所有面板的厚度"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'

# 先获取所有面板名
$dex.DoDataExtraction("HULL.PANEL(*).NAME")
$panelTree = $dex.GetResTree()
$panels = $panelTree | Where-Object { $_ -ne "" -and $_ -notmatch "^(HULL|PANEL|NAME)$" }

foreach ($panel in $panels) {
    $dex.DoDataExtraction("HULL.PANEL('" + $panel + "').PLATE(*).THICKNESS")
    $thickTree = $dex.GetResTree()
    $thicknesses = ($thickTree | Where-Object { $_ -match '^\d+\.?\d*$' }) -join ", "
    Write-Output ("$panel : $thicknesses mm")
}
```

---

## 任务：查询管路重量（"M4-SA1-A 管路的重量"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
# 格式：PIPE('管路系统').PIPSPOOL('卷号').GEN_PROP.WEIGHT
$dex.DoDataExtraction("PIPE('300').PIPSPOOL('M4-SA1-A').GEN_PROP.WEIGHT")
Write-Output ("重量: " + $dex.GetValue() + " kg")
```

---

## 任务：列出所有管路模型（"有哪些管路"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$dex.DoDataExtraction("PIPE('*').PIPMODEL('P'*).NAME")
$tree = $dex.GetResTree()
$names = $tree | Where-Object { $_ -ne "" -and $_ -notmatch "^(PIPE|PIPMODEL|NAME)$" }
Write-Output ("共 " + $names.Count + " 个管路模型:")
$names | ForEach-Object { Write-Output ("  " + $_) }
```

---

## 任务：列出所有设备（"有哪些设备"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
$dex.DoDataExtraction("EQUIP.ITEM(*).NAME")
$tree = $dex.GetResTree()
$items = $tree | Where-Object { $_ -ne "" -and $_ -notmatch "^(EQUIP|ITEM|NAME)$" }
Write-Output ("共 " + $items.Count + " 个设备:")
$items | ForEach-Object { Write-Output ("  " + $_) }
```

---

## 常用查询表达式速查

| 用户想查什么 | DEX 表达式 |
|---|---|
| 所有面板名 | `HULL.PANEL(*).NAME` |
| 面板 X 的板件厚度 | `HULL.PANEL('X').PLATE(*).THICKNESS` |
| 面板 X 的板件材料 | `HULL.PANEL('X').PLATE(*).MATERIAL` |
| 面板 X 的板件重量 | `HULL.PANEL('X').PLATE(*).WEIGHT` |
| 面板 X 的板件面积 | `HULL.PANEL('X').PLATE(*).AREA` |
| 加强筋端部参数 | `HULL.PAN('X').STI(1:27).END(1:2).CUT.PAR` |
| 管路卷重量 | `PIPE('300').PIPSPOOL('M4-SA1-A').GEN_PROP.WEIGHT` |
| 所有管路模型 | `PIPE('*').PIPMODEL('P'*).NAME` |
| 所有设备 | `EQUIP.ITEM(*).NAME` |
| 组件连接件公称径 | `COMP('MainC').PIPE.CON(1:2).NOMINAL` |

**通配符规则：**
- `(*)` 匹配所有对象
- `('名称*')` 按前缀通配，如 `('TB172*')`
- `(1:10)` 索引范围，第 1 到第 10 个

---

## 任务：读取模型的用户自定义属性（"查询管路 PIPE-001 的 status 属性"）

用户自定义属性（`kcs_att`）需要在 Vitesse 脚本中操作，写脚本文件后执行：

```python
# 写入 C:\Tribon\M3\Projects\M3sp\macro\src\pisci_task.py
import kcs_att, kcs_util
import KcsModel

# 定义模型对象
model = KcsModel.Model()
model.Type = "pipe"         # <- 模型类型：pipe / equipment / plane panel / assembly 等
model.Name = "PIPE-001"     # <- 模型名称

# kcs_att 用法：先获取第一个属性，再遍历
attr = kcs_att.attribute_first_get(model)
while attr:
    print "属性:", str(attr)
    attr = kcs_att.attribute_next_get()
```

---

## 任务：批量写入用户自定义属性（"给所有面板写入 status=1"）

```python
# 写入脚本文件后执行
import kcs_att, kcs_dex, kcs_util
import KcsModel

ok = kcs_util.ok()

# 获取所有面板名
panels = []
res = kcs_dex.extract("HULL.PANEL(*).NAME")
if res == ok:
    while True:
        typ = kcs_dex.next_result()
        if typ == 0: break
        if typ == 3: panels.append(kcs_dex.get_string())

# 属性模板：类别名/模板名（需在 Tribon Toolkit Preferences 中预先定义）
category = "hull"     # <- 属性类别名
template = "status"   # <- 属性模板名
value    = 1          # <- 要写入的整数值

for name in panels:
    model = KcsModel.Model()
    model.Type = "plane panel"
    model.Name = name
    try:
        attr = kcs_att.attribute_first_get(model)
        if not attr:
            attr = kcs_att.attribute_create(model, category, template)
        kcs_att.integer_set(model, attr, 0, value)
        kcs_att.model_save(model)
        print "已写入: " + name
    except Exception as e:
        print "失败: " + name + " - " + str(kcs_att.error)
```

---

## 任务：查询面板的用户自定义属性（DEX 方式）

如果属性已知为 DEX 可见的标准属性，可通过 DEX 读取（只读）：

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ps = New-Object -ComObject 'Tbprojectselect.TBProjSelect'
$ps.SelectProjectBatch("", "M3sp", "")
$dex = New-Object -ComObject 'TBDex.TBDex'
# USER_ATTRIBUTE(i)：i 为属性索引（从 1 开始）
$dex.DoDataExtraction("HULL.PANEL('BHD122').USER_ATTRIBUTE(1)")
Write-Output ("自定义属性1: " + $dex.GetValue())
```