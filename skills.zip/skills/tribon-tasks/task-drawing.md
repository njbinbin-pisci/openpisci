# Tribon M3 — 图纸打印任务

> 所有 COM 调用：`com_invoke` 工具，参数 `arch: "x86"`

---

## 任务：查找项目中有哪些图纸（"有哪些船体图纸"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()
try {
    $fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
    $fd.DrawingType = "HULL"   # ← HULL / PIPE / EQUIP / CABLE / STRUCT
    $fd.Filter = "*"           # ← * 匹配全部，或用 "BHD*" 按前缀过滤
    $drawings = $fd.Find()
    Write-Output ("找到 " + $drawings.Count + " 张图纸:")
    foreach ($d in $drawings) {
        Write-Output ("  " + $d.Name + "  类型:" + $d.Type + "  状态:" + $d.Status)
    }
} finally { $app.Terminate() }
```

图纸类型（`DrawingType`）：`HULL`（船体）、`PIPE`（管路）、`EQUIP`（设备）、`CABLE`（电缆）、`STRUCT`（结构）

---

## 任务：打印指定图纸到打印机（"打印 BHD122 图纸"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()
try {
    # 查找目标图纸
    $fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
    $fd.DrawingType = "HULL"
    $fd.Filter = "BHD122"   # ← 精确名称或通配符
    $drawings = $fd.Find()

    if ($drawings.Count -eq 0) {
        Write-Output "未找到匹配图纸"
    } else {
        # 配置打印机
        $pj = New-Object -ComObject 'TBPrintSrv.PrintJob'
        $pj.Printer.DeviceName = "Microsoft Print to PDF"   # ← 替换为实际打印机名
        $pj.Printer.Orientation = 2   # 1=纵向, 2=横向
        $pj.Drawings = $drawings
        $pj.StartPrint()
        Write-Output ("已发送 " + $drawings.Count + " 张图纸到打印机")
    }
} finally { $app.Terminate() }
```

---

## 任务：批量打印所有船体图纸为 PDF（"把所有船体图纸导出为 PDF"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()
try {
    $fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
    $fd.DrawingType = "HULL"
    $fd.Filter = "*"
    $drawings = $fd.Find()

    $pj = New-Object -ComObject 'TBPrintSrv.PrintJob'
    $pj.Printer.DeviceName = "Microsoft Print to PDF"
    $pj.Printer.PaperSize = 8    # 8=A3, 9=A4
    $pj.Printer.Orientation = 2  # 横向
    $pj.Drawings = $drawings
    $pj.StartPrint()
    Write-Output ("批量打印完成，共 " + $drawings.Count + " 张")
} finally { $app.Terminate() }
```

---

## 任务：查看系统中可用的打印机列表

```powershell
# shell, interpreter=powershell
Get-Printer | Select-Object Name, DriverName, PortName | Format-Table -AutoSize
```

---

## 任务：打印管路图纸（"打印 SA1 系统的管路图"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$app = New-Object -ComObject 'TBPrintSrv.TBApplication'
$app.Initialize()
try {
    $fd = New-Object -ComObject 'TBPrintSrv.FindDrawings'
    $fd.DrawingType = "PIPE"
    $fd.Filter = "SA1*"   # ← 按系统名前缀过滤
    $drawings = $fd.Find()
    Write-Output ("找到 " + $drawings.Count + " 张管路图纸")

    if ($drawings.Count -gt 0) {
        $pj = New-Object -ComObject 'TBPrintSrv.PrintJob'
        $pj.Printer.DeviceName = "Microsoft Print to PDF"
        $pj.Drawings = $drawings
        $pj.StartPrint()
        Write-Output "打印完成"
    }
} finally { $app.Terminate() }
```
