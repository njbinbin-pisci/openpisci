# Tribon M3 — 装配与零件清单任务（BOM）

> 所有 COM 调用：`com_invoke` 工具，参数 `arch: "x86"`

---

## 任务：查询装配的基本信息（重量、状态、描述）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
$plg.CalculateProperties = $true

$assemblyName = "BLOCK-001"   # ← 替换为目标装配名
$ap = $plg.GetAssemblyProperties($assemblyName)

Write-Output ("装配名:   " + $ap.NodeName)
Write-Output ("描述:     " + $ap.Description)
Write-Output ("类型:     " + $ap.AssemblyType)
Write-Output ("设计状态: " + $ap.DesignStatus)
Write-Output ("制造状态: " + $ap.ManufacturingStatus)
Write-Output ("计算重量: " + $ap.CalculatedWeight + " kg")
Write-Output ("估算重量: " + $ap.EstimatedWeight + " kg")
Write-Output ("计划单元: " + $ap.PlanningUnit)
Write-Output ("工作位置: " + $ap.WorkLocation)
Write-Output ("零件数量: " + $ap.GetPartCount())
Write-Output ("子装配数: " + $ap.GetSubAssembliesCount())
```

---

## 任务：列出装配的所有零件（"BLOCK-001 有哪些零件"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
$plg.CalculateProperties = $true

$assemblyName = "BLOCK-001"   # ← 替换
$ap = $plg.GetAssemblyProperties($assemblyName)

Write-Output ("装配 $assemblyName 共 " + $ap.GetPartCount() + " 个零件:")
Write-Output ("零件名 | 类型 | 材料 | 重量(kg) | 数量")
Write-Output ("----------------------------------------------")
for ($i = 0; $i -lt $ap.GetPartCount(); $i++) {
    $p = $ap.GetPartProperties($i)
    Write-Output ($p.Name + " | " + $p.PartType + " | " + $p.MaterialNumber + " | " + $p.Weight + " | x" + $p.Quantity)
}
```

---

## 任务：递归查看整个装配树（"显示 BLOCK-001 的完整层级"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
$plg.Recursive = $true
$plg.CalculateProperties = $true

function Show-Assembly($name, $indent) {
    $ap = $plg.GetAssemblyProperties($name)
    $pad = "  " * $indent
    Write-Output ($pad + "[" + $ap.AssemblyType + "] " + $ap.NodeName + "  重量:" + $ap.CalculatedWeight + "kg  状态:" + $ap.DesignStatus)
    for ($i = 0; $i -lt $ap.GetPartCount(); $i++) {
        $p = $ap.GetPartProperties($i)
        Write-Output ($pad + "  ▸ " + $p.Name + "  " + $p.MaterialNumber + "  " + $p.Weight + "kg x" + $p.Quantity)
    }
    for ($i = 0; $i -lt $ap.GetSubAssembliesCount(); $i++) {
        $sub = $ap.GetSubAssembly($i)
        Show-Assembly $sub.NodeName ($indent + 1)
    }
}

Show-Assembly "BLOCK-001" 0   # ← 替换为目标装配名
```

---

## 任务：计算装配重量和重心（"BLOCK-001 的重心在哪"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$mc = New-Object -ComObject 'TBModelCalculations.TBModelCalc'
$result = $mc.GetWeightAndCOG("BLOCK-001", "assembly")   # ← 替换装配名
Write-Output ("重量:   " + $result.Weight + " kg")
Write-Output ("重心 X: " + $result.COGX + " mm")
Write-Output ("重心 Y: " + $result.COGY + " mm")
Write-Output ("重心 Z: " + $result.COGZ + " mm")
```

---

## 任务：生成零件清单文件（输出到目录）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
$plg.OutputDirectory = "C:\temp\parts_list"   # ← 确保目录存在
$plg.Recursive = $true
$plg.CalculateProperties = $true
$plg.CumulateHullParts = $true

New-Item -ItemType Directory -Force -Path "C:\temp\parts_list" | Out-Null
$plg.GeneratePartsList("BLOCK-001")   # ← 替换装配名
Write-Output ("零件清单已输出到 C:\temp\parts_list\")
Get-ChildItem "C:\temp\parts_list" | Select-Object Name, Length
```

---

## 任务：查询装配的计划日期（"BLOCK-001 的计划开始时间"）

```powershell
# com_invoke, arch=x86
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$plg = New-Object -ComObject 'TbPartsListGen.TbAssPartsListGen'
$plg.CalculateProperties = $true
$ap = $plg.GetAssemblyProperties("BLOCK-001")   # ← 替换
Write-Output ("计划开始: " + $ap.PlannedStartDate)
Write-Output ("计划完成: " + $ap.PlannedEndDate)
Write-Output ("实际开始: " + $ap.ActualStartDate)
Write-Output ("实际完成: " + $ap.ActualEndDate)
```
