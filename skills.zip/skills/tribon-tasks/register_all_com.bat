@echo off
echo ========================================
echo Tribon COM组件注册脚本
echo 版本: 1.1
echo 日期: 2026-03-23
echo ========================================
echo.

echo 注意：需要以管理员权限运行此脚本！
echo.

echo 正在检查Tribon目录...
if not exist "C:\Tribon\M3\Bin\" (
    echo 错误：Tribon M3未安装或路径不正确！
    echo 请确认Tribon M3已安装在C:\Tribon\M3
    pause
    exit /b 1
)

echo Tribon目录存在，开始注册COM组件...
echo.

cd /d "C:\Tribon\M3\Bin"

echo [1/4] 注册核心DLL组件...
regsvr32 /s tbps.dll
regsvr32 /s tbpsps.dll
regsvr32 /s tbruntime.dll
regsvr32 /s tbdbaccess.dll
regsvr32 /s TbDotComOnClient.dll
regsvr32 /s tbprojectselect.dll
regsvr32 /s tbrmtfile.dll
regsvr32 /s tbbatchjob.dll

echo [2/4] 注册服务DLL组件...
regsvr32 /s TbPrintSrv.dll
regsvr32 /s TbQuerySrv.dll
regsvr32 /s TbDocumentSrv.dll
regsvr32 /s TbModelViewer.dll
regsvr32 /s TbModelCalculations.dll

echo [3/4] 注册其他DLL组件...
regsvr32 /s tbexpimp.dll
regsvr32 /s tbcommon.dll
regsvr32 /s TbMORMgr.dll
regsvr32 /s TbCadInterface.dll
regsvr32 /s TBPresentCollisions.dll
regsvr32 /s TbGenPostprocessor.dll
regsvr32 /s tbtmsrv.dll
regsvr32 /s TbGraph.ocx
regsvr32 /s calcx_m3.dll

echo [4/4] 注册EXE组件...
if exist "tbjlaunch.exe" tbjlaunch.exe /regserver
if exist "tbdexint.exe" tbdexint.exe /regserver
if exist "tbtransfer.exe" tbtransfer.exe /regserver
if exist "TbPartsListGen.exe" TbPartsListGen.exe /regserver

echo.
echo ========================================
echo COM组件注册完成！
echo.
echo 建议运行验证脚本检查注册结果：
echo PowerShell -ExecutionPolicy Bypass -File "verify_com_objects.ps1"
echo ========================================
echo.
pause