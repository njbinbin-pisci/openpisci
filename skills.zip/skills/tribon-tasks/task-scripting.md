# Tribon M3 — 脚本、宏与钩子任务

---

## 一、执行 Python（Vitesse）脚本

> **重要**：Tribon M3 的 Python 2.3 是**嵌入式**解释器，没有独立的 `python.exe`。
> 脚本必须通过 Tribon 的作业系统（TBJob COM 或 tbstartjob.exe）执行，
> 不能用系统 Python 或直接调用 `python.exe`。

### 任务：运行一个 Python 脚本（"执行 my_script.py"）

**第一步：用 `file_write` 工具将脚本写入 Tribon 项目的 macro/src 目录**
```
C:\Tribon\M3\Projects\M3sp\macro\src\my_script.py
```

**第二步（推荐）：通过 TBJob COM 对象提交作业**
```powershell
# com_invoke, arch=x86
$job = New-Object -ComObject 'TBJob.TBJob'
$job.Create("VITESSE", "M3sp")   # ← 第二个参数为项目名（如 M3sp）
$job.CommandLine = "C:\Tribon\M3\Projects\M3sp\macro\src\my_script.py"
$job.Run()
Write-Output ("作业已提交，ID: " + $job.jobId)
```

> `CommandLine` 只需填脚本路径，**不要**加 `python.exe` 前缀，TBJob 会自动用内置解释器执行。

**第二步（备选）：通过 tbstartjob.exe 命令行提交**
```bat
rem shell, interpreter=cmd
cd C:\Tribon\M3\Projects\M3sp
C:\Tribon\M3\Bin\tbsetenv.exe M3sp
C:\Tribon\M3\Bin\tbstartjob.exe VITESSE M3sp "C:\Tribon\M3\Projects\M3sp\macro\src\my_script.py"
```

---

### 任务：创建一个设备（"在 Tribon 里创建设备 PUMP-001"）

写入脚本文件，然后执行：
```python
# 写入 C:\Tribon\M3\Projects\M3sp\macro\src\pisci_task.py
import kcs_equip, kcs_util
ok = kcs_util.ok()

name = "PUMP-001"       # ← 设备名
module = "MAIN_ENGINE"  # ← 所属模块

kcs_equip.equip_new(name, module)
kcs_equip.equip_description_set("主泵")
kcs_equip.equip_save()
print "设备创建完成:", name
```

---

### 任务：创建电缆并连接设备（"创建电缆 CABLE-001 连接 PUMP-001 和 PANEL-A"）

```python
# 写入脚本文件
import kcs_cable, kcs_util
ok = kcs_util.ok()

kcs_cable.cable_new("CABLE-001")
kcs_cable.cable_activate("CABLE-001")
kcs_cable.cable_component_set("CABLE_COMP")
kcs_cable.cable_equipment_connect("PUMP-001", 1)   # 端点1
kcs_cable.cable_equipment_connect("PANEL-A", 2)    # 端点2
kcs_cable.cable_save()
print "电缆创建完成"
```

---

### 任务：计算装配焊缝（"计算 BLOCK-001 的焊接量"）

```python
# 写入脚本文件
import kcs_weld

weld_table = kcs_weld.weld_calculation("BLOCK-001")   # ← 替换装配名
total_length = 0.0
for i in range(weld_table.GetJointCount()):
    joint = weld_table.GetJoint(i)
    for j in range(joint.GetWeldCount()):
        weld = joint.GetWeld(j)
        total_length += weld.Length if hasattr(weld, 'Length') else 0
        print "接头%d 焊缝%d: %s" % (i, j, weld.WeldComment)
weld_table.Save()
print "焊缝计算完成，总长度:", total_length
```

---

## 二、执行 GML 宏

### 任务：运行一个 GML 宏（"执行宏 MY_MACRO"）

```powershell
# com_invoke, arch=x86
$job = New-Object -ComObject 'TBJob.TBJob'
$job.Create("MACRO", "M3sp")
$job.CommandLine = "C:\Tribon\M3\Bin\tbmacro.exe MY_MACRO"   # ← 替换宏名
$job.Run()
```

或通过 shell：
```bat
rem shell, interpreter=cmd
cd C:\Tribon\M3\Projects\M3sp
C:\Tribon\M3\Bin\tbsetenv.exe M3sp
C:\Tribon\M3\Bin\tbmacro.exe MY_MACRO
```

---

### 任务：编写并运行一个批量提取报表的宏（"生成面板加强筋参数报表"）

**第一步：用 `file_write` 写入宏文件**
```
路径：C:\Tribon\M3\Projects\M3sp\macro\src\STIF.mac
```
内容：
```
MACRO, STIF;
ASSIGN,FILENAME,'C:\temp\STIF.LST';
ASSIGN,STR,'HUL.PAN(TB*).STI(1:27).END(1:2).CUT.PAR';
EXTRACT,TREE,STR;
ASSIGN,HEAD,' OBJECT                    STI  END    PARAMETERS';
TABLE,TAB/ARGUMENTS=(HEAD)/FILENAME=FILENAME/FORMAT=(-60,)/NOAPPEND;
GET/RANGE=(PANELS,STAT,TREE,);
IF,STAT == 1;
  LOOP,PANEL,PANELS;
    GET/RANGE=(STIFFENERS,STAT,TREE,,PANEL);
    IF,STAT == 1;
      LOOP,STI,STIFFENERS;
        GET/RANGE=(RNG,STAT,TREE,,PANEL,STI);
        IF,STAT == 1;
          LOOP,I,RNG;
            GET/EXTRACT=(PARAM,STAT,TREE,,PANEL,STI,I,,);
            IF,STAT == 1;
              GET/STRUCTURE=(N,PARAM,-1);
              LOOP,J,1:N::3;
                ASSIGN,K,J;
                GET/STRUCTURE=(P1,PARAM,K);
                ASSIGN,K,K+1;
                IF,K <= N;
                  GET/STRUCTURE=(P2,PARAM,K);
                  ASSIGN,K,K+1;
                  IF,K <= N;
                    GET/STRUCTURE=(P3,PARAM,K);
                    TABLE,TAB/ARGUMENTS=(PANEL,STI,I,P1,P2,P3)
                             /FILENAME=FILENAME
                             /FORMAT=(-24,,5,0,5,0,10,2,10,2,10,2);
                  ENDIF;
                ENDIF;
              ENDLOOP;
            ENDIF;
          ENDLOOP;
        ENDIF;
      ENDLOOP;
    ENDIF;
  ENDLOOP;
ENDIF;
ENDMACRO;
```

**第二步：执行宏**
```powershell
# com_invoke, arch=x86
$job = New-Object -ComObject 'TBJob.TBJob'
$job.Create("MACRO", "M3sp")
$job.CommandLine = "C:\Tribon\M3\Bin\tbmacro.exe STIF"
$job.Run()
```

---

## 三、部署钩子脚本

### 任务：部署公式钩子（"自定义 $-value 公式 10001"）

**第一步：用 `file_write` 写入钩子文件**
```
路径：C:\Tribon\M3\Projects\M3sp\macro\src\_TBhook_Formula.py
```
内容模板：
```python
import kcs_dex, kcs_util
ok = kcs_util.success()

def getFormula(ModelType, ModelName, PartType, PartId, SubPartType, SubPartId,
               ReflCode, FormulaNumber,
               ParNInt, ParNRea, ParNStr,
               PI0, PI1, PI2, PI3, PI4, PI5, PI6, PI7, PI8, PI9,
               PR0, PR1, PR2, PR3, PR4, PR5, PR6, PR7, PR8, PR9,
               PS0, PS1, PS2, PS3, PS4, PS5, PS6, PS7, PS8, PS9):

    FormulaValue = ''

    if FormulaNumber == 10001:
        # ← 在此写自定义逻辑
        est = "HULL.PLATE('" + ModelName + "').HOLE_GRINDING"
        res = kcs_dex.extract(est)
        if res == ok:
            kcs_dex.next_result()
            val = kcs_dex.get_string()
            FormulaValue = '*' if val == "YES" else ''

    return (FormulaValue,
            0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            '', '', '', '', '', '', '', '', '', '')
```

**第二步：重启 Tribon 应用使钩子生效**（钩子在 Tribon 启动时加载）

---

### 任务：部署零件命名钩子（"修改零件名规则"）

```
路径：C:\Tribon\M3\Projects\M3sp\macro\src\_TBhook_CustPartName.py
```
内容模板：
```python
def getPartName(Project, Assembly, Block, Module, System, Drawing, Location,
                PositionName, PositionNo, BracketPositionNo, SymmetryCode,
                BuiltProfile, GPS1, GPS2, GPS3, GPS4,
                TribonPartName, StoringCode, RulePartName):
    CustPartName = ''

    # 示例：去掉末尾的位置号后缀（"121-BK40A-A35" → "121-BK40A-A"）
    parts = RulePartName.split('-')
    if parts and len(parts[-1]) > 1:
        last = parts[-1]
        if last[0] == 'A' and last[1:].isdigit():
            CustPartName = '-'.join(parts[:-1]) + '-A'

    return CustPartName   # 返回空字符串则使用 Tribon 默认规则
```
